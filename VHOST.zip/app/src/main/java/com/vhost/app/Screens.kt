@file:OptIn(ExperimentalMaterial3Api::class)

package com.vhost.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val CardShape = RoundedCornerShape(10.dp)

private fun formatRam(mb: Int): String =
    if (mb % 1024 == 0) "${mb / 1024} GB" else String.format("%.1f GB", mb / 1024f)

private fun formatMinutes(min: Int): String =
    if (min % 60 == 0 && min >= 60) "${min / 60} h" else "$min min"

// =====================================================================
// Home
// =====================================================================

@Composable
fun HomeScreen(
    prefs: Prefs,
    updater: Updater,
    java: JavaRuntime,
    onOpenSettings: () -> Unit,
    onOpenJava: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 12.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "VHOST",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 3.sp,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onOpenSettings) {
                Icon(
                    Icons.Filled.Settings,
                    contentDescription = "Settings",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        UpdateBanner(updater)

        ServerCard()
        Spacer(Modifier.height(16.dp))
        JavaCard(java, onOpenJava)
        Spacer(Modifier.height(16.dp))
        DefaultsCard(prefs, onOpenSettings)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun UpdateBanner(updater: Updater) {
    when (updater.state) {
        Updater.State.Available -> {
            BannerCard {
                Text("Update available", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "Build ${updater.newBuild} is ready. You have build ${BuildConfig.VERSION_CODE}.",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (updater.notes.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        updater.notes.trim(),
                        fontSize = 14.sp,
                        maxLines = 5,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { updater.download() }) { Text("Update now") }
                    TextButton(onClick = { updater.dismiss() }) { Text("Later") }
                }
            }
        }
        Updater.State.Downloading -> {
            BannerCard {
                Text("Downloading update", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = updater.progress,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Updater.State.ReadyToInstall -> {
            BannerCard {
                Text("Update downloaded", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                if (updater.message.isNotBlank()) {
                    Text(
                        updater.message,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(12.dp))
                Button(onClick = { updater.install() }) { Text("Install") }
            }
        }
        Updater.State.Error -> {
            if (updater.message.isNotBlank()) {
                BannerCard {
                    Text("Update problem", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        updater.message,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { updater.dismiss() }) { Text("Dismiss") }
                }
            }
        }
        else -> {}
    }
}

@Composable
private fun BannerCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp)
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
private fun ServerCard() {
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.outline)
                )
                Spacer(Modifier.size(10.dp))
                Text("Offline", fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "No server created yet.",
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(20.dp))
            Button(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth()) {
                Text("Create server")
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "Set up Java first. The server itself comes right after Java works on your device.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun JavaCard(java: JavaRuntime, onOpen: () -> Unit) {
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpen() }
    ) {
        Column(Modifier.padding(20.dp)) {
            Text("Java", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                when (java.state) {
                    JavaRuntime.State.NotInstalled -> "Not installed"
                    JavaRuntime.State.Installing -> "Installing…"
                    JavaRuntime.State.Ready -> java.summary
                    JavaRuntime.State.Failed -> "Setup failed. Tap to see the log."
                },
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(6.dp))
            Text(
                if (java.state == JavaRuntime.State.Ready) "Tap to open" else "Tap to set up",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun DefaultsCard(prefs: Prefs, onOpenSettings: () -> Unit) {
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenSettings() }
    ) {
        Column(Modifier.padding(20.dp)) {
            Text("Server defaults", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            InfoRow("Memory", formatRam(prefs.ramMb))
            InfoRow("Port", prefs.port.toString())
            InfoRow("Max players", prefs.maxPlayers.toString())
            Spacer(Modifier.height(6.dp))
            Text(
                "Tap to change in settings",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Text(
            label,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

// =====================================================================
// Settings
// =====================================================================

@Composable
fun SettingsScreen(prefs: Prefs, updater: Updater, onBack: () -> Unit) {
    var confirmReset by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            // ---------------- Updates ----------------
            SectionTitle("Updates")
            SettingsCard {
                SwitchRow(
                    "Check for updates when VHOST opens",
                    "Shows a banner on the home screen when a new build is on GitHub.",
                    prefs.checkUpdatesOnStart
                ) { prefs.putCheckUpdatesOnStart(it) }
                RowDivider()
                Column(Modifier.padding(16.dp)) {
                    Text("Update source", fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text(
                        "GitHub owner/repo. The repo must be public.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = prefs.updateRepo,
                        onValueChange = { prefs.putUpdateRepo(it) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                RowDivider()
                Column(Modifier.padding(16.dp)) {
                    Text(
                        "Installed: build ${BuildConfig.VERSION_CODE}",
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    when (updater.state) {
                        Updater.State.Checking -> Text("Checking…", fontSize = 15.sp)
                        Updater.State.Available -> {
                            Text("Build ${updater.newBuild} is available.", fontSize = 15.sp)
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { updater.download() }) { Text("Download update") }
                        }
                        Updater.State.Downloading -> {
                            Text("Downloading…", fontSize = 15.sp)
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = updater.progress,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Updater.State.ReadyToInstall -> {
                            Text("Update downloaded.", fontSize = 15.sp)
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { updater.install() }) { Text("Install") }
                        }
                        else -> {
                            if (updater.message.isNotBlank()) {
                                Text(updater.message, fontSize = 15.sp)
                                Spacer(Modifier.height(8.dp))
                            }
                            OutlinedButton(onClick = { updater.check(prefs.updateRepo) }) {
                                Text("Check for updates")
                            }
                        }
                    }
                }
            }

            // ---------------- Appearance ----------------
            SectionTitle("Appearance")
            SettingsCard {
                ChoiceRow(
                    "Theme",
                    listOf("dark" to "Dark", "light" to "Light", "system" to "Same as phone"),
                    prefs.theme
                ) { prefs.putTheme(it) }
                RowDivider()
                Column(Modifier.padding(16.dp)) {
                    val current = AccentOptions.firstOrNull { it.key == prefs.accent }
                    Text("Accent colour", fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text(
                        current?.label ?: "",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        AccentOptions.forEach { option ->
                            val selected = option.key == prefs.accent
                            Box(
                                Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(option.color)
                                    .border(
                                        width = if (selected) 3.dp else 0.dp,
                                        color = MaterialTheme.colorScheme.onBackground,
                                        shape = CircleShape
                                    )
                                    .clickable { prefs.putAccent(option.key) }
                            )
                        }
                    }
                }
            }

            // ---------------- Server defaults ----------------
            SectionTitle("Server defaults")
            Text(
                "Saved now. They start working when the server runner arrives in the next build.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 4.dp, end = 4.dp, bottom = 8.dp)
            )
            SettingsCard {
                SliderRow(
                    title = "Memory for the server",
                    value = prefs.ramMb.toFloat(),
                    range = 512f..6144f,
                    steps = 21,
                    label = { formatRam(it.roundToInt()) },
                    onFinished = { prefs.putRamMb(it.roundToInt()) }
                )
                RowDivider()
                PortRow(prefs)
                RowDivider()
                SliderRow(
                    title = "Max players",
                    value = prefs.maxPlayers.toFloat(),
                    range = 2f..50f,
                    steps = 47,
                    label = { "${it.roundToInt()}" },
                    onFinished = { prefs.putMaxPlayers(it.roundToInt()) }
                )
            }

            // ---------------- Running in the background ----------------
            SectionTitle("Running in the background")
            SettingsCard {
                SwitchRow(
                    "Start the server when VHOST opens",
                    "Starts the last server you used.",
                    prefs.autoStartOnOpen
                ) { prefs.putAutoStartOnOpen(it) }
                RowDivider()
                SwitchRow(
                    "Restart if the server crashes",
                    "Starts it again automatically.",
                    prefs.autoRestartOnCrash
                ) { prefs.putAutoRestartOnCrash(it) }
                RowDivider()
                SwitchRow(
                    "Keep the phone awake for the server",
                    "Stops Android from pausing the server while the screen is off.",
                    prefs.keepAwake
                ) { prefs.putKeepAwake(it) }
                RowDivider()
                SwitchRow(
                    "Only run while charging",
                    "Stops the server when you unplug.",
                    prefs.onlyWhileCharging
                ) { prefs.putOnlyWhileCharging(it) }
                RowDivider()
                SwitchRow(
                    "Stop the server when battery is low",
                    "Protects the phone from running flat.",
                    prefs.stopOnLowBattery
                ) { prefs.putStopOnLowBattery(it) }
                if (prefs.stopOnLowBattery) {
                    SliderRow(
                        title = "Stop at",
                        value = prefs.lowBatteryPercent.toFloat(),
                        range = 5f..50f,
                        steps = 8,
                        label = { "${it.roundToInt()}%" },
                        onFinished = { prefs.putLowBatteryPercent(it.roundToInt()) }
                    )
                }
                RowDivider()
                SwitchRow(
                    "Only run on Wi-Fi",
                    "Stops the server on mobile data so it does not use your data plan.",
                    prefs.onlyOnWifi
                ) { prefs.putOnlyOnWifi(it) }
                RowDivider()
                SwitchRow(
                    "Stop when nobody is playing",
                    "Saves battery and heat.",
                    prefs.autoStopWhenEmpty
                ) { prefs.putAutoStopWhenEmpty(it) }
                if (prefs.autoStopWhenEmpty) {
                    ChoiceRow(
                        "Stop after the server has been empty for",
                        listOf("10" to "10 min", "30" to "30 min", "60" to "1 h", "180" to "3 h"),
                        prefs.emptyStopMinutes.toString()
                    ) { prefs.putEmptyStopMinutes(it.toInt()) }
                }
            }

            // ---------------- Backups ----------------
            SectionTitle("Backups")
            SettingsCard {
                SwitchRow(
                    "Back up the world automatically",
                    "Keeps a copy of your world while the server runs.",
                    prefs.autoBackup
                ) { prefs.putAutoBackup(it) }
                if (prefs.autoBackup) {
                    ChoiceRow(
                        "Back up every",
                        listOf("15" to "15 min", "30" to "30 min", "60" to "1 h", "180" to "3 h"),
                        prefs.backupEveryMinutes.toString()
                    ) { prefs.putBackupEveryMinutes(it.toInt()) }
                }
            }

            // ---------------- Notifications ----------------
            SectionTitle("Notifications")
            SettingsCard {
                SwitchRow(
                    "Server started or stopped",
                    "",
                    prefs.notifyStarted
                ) { prefs.putNotifyStarted(it) }
                RowDivider()
                SwitchRow(
                    "A player joins or leaves",
                    "",
                    prefs.notifyPlayerJoin
                ) { prefs.putNotifyPlayerJoin(it) }
                RowDivider()
                SwitchRow(
                    "The server crashes",
                    "",
                    prefs.notifyCrash
                ) { prefs.putNotifyCrash(it) }
            }

            // ---------------- About ----------------
            SectionTitle("About")
            SettingsCard {
                Column(Modifier.padding(16.dp)) {
                    InfoRow("Version", BuildConfig.VERSION_NAME)
                    InfoRow("Build", BuildConfig.VERSION_CODE.toString())
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { confirmReset = true }) {
                        Text("Reset all settings")
                    }
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset all settings?") },
            text = { Text("Every setting goes back to its default. Your servers are not touched.") },
            confirmButton = {
                TextButton(onClick = {
                    prefs.resetAll()
                    confirmReset = false
                }) { Text("Reset") }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("Cancel") }
            }
        )
    }
}

// ---------------------------------------------------------------------
// Settings building blocks
// ---------------------------------------------------------------------

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        fontSize = 15.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 4.dp, top = 22.dp, bottom = 8.dp)
    )
}

@Composable
private fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = CardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(content = content)
    }
}

@Composable
private fun RowDivider() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(MaterialTheme.colorScheme.outlineVariant)
    )
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            if (subtitle.isNotEmpty()) {
                Text(
                    subtitle,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(
    title: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int,
    label: (Float) -> String,
    onFinished: (Float) -> Unit
) {
    var temp by remember(value) { mutableStateOf(value) }
    Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )
            Text(
                label(temp),
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold
            )
        }
        Slider(
            value = temp,
            onValueChange = { temp = it },
            onValueChangeFinished = { onFinished(temp) },
            valueRange = range,
            steps = steps
        )
    }
}

@Composable
private fun ChoiceRow(
    title: String,
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Column(Modifier.padding(16.dp)) {
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.forEach { (key, text) ->
                FilterChip(
                    selected = key == selected,
                    onClick = { onSelect(key) },
                    label = { Text(text) }
                )
            }
        }
    }
}

@Composable
private fun PortRow(prefs: Prefs) {
    var text by remember { mutableStateOf(prefs.port.toString()) }
    val valid = text.toIntOrNull()?.let { it in 1024..65535 } ?: false
    Column(Modifier.padding(16.dp)) {
        Text("Server port", fontSize = 16.sp, fontWeight = FontWeight.Medium)
        Text(
            "Use a number from 1024 to 65535. The usual one is 25565.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { input ->
                val clean = input.filter { it.isDigit() }.take(5)
                text = clean
                val n = clean.toIntOrNull()
                if (n != null && n in 1024..65535) prefs.putPort(n)
            },
            isError = !valid,
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
    }
}
