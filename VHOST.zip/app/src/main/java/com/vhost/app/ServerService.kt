package com.vhost.app

import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * Keeps VHOST alive in the background while the server runs and shows the
 * notification with a Stop button. The server itself lives in ServerManager.
 */
class ServerService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val server = Shared.server(this)
        if (intent?.action == ACTION_STOP) {
            Handler(Looper.getMainLooper()).post { server.stop() }
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, server.buildNotification())
        if (server.state == ServerManager.State.Stopped) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    companion object {
        const val ACTION_STOP = "com.vhost.app.STOP"
        const val NOTIF_ID = 42
    }
}
