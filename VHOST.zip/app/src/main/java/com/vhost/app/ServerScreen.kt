package com.vhost.app

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ServerScreen(
    server: ServerManager,
    prefs: Prefs,
    tunnel: TunnelManager,
    onOpenTunnel: () -> Unit,
    onBack: () -> Unit
) {
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var showEula by remember { mutableStateOf(false) }
    var command by remember { mutableStateOf("") }
    var versionText by remember { mutableStateOf(prefs.mcVersion) }

    val state = server.state
    val stopped = state == ServerManager.State.Stopped
    val running = state == ServerManager.State.Running

    val consoleScroll = rememberScrollState()
    LaunchedEffect(server.console.size) {
        consoleScroll.scrollTo(consoleScroll.maxValue)
    }

    val dot = when (state) {
        ServerManager.State.Running -> Color(0xFF4CAF50)
        ServerManager.State.Stopped -> MaterialTheme.colorScheme.outline
        else -> Color(0xFFFFB300)
    }
    val title = when (state) {
        ServerManager.State.Stopped -> "Offline"
        ServerManager.State.Preparing -> "Getting ready"
        ServerManager.State.Starting -> "Starting"
        ServerManager.State.Running -> "Online"
        ServerManager.State.Stopping -> "Stopping"
    }

    fun sendNow() {
        server.sendCommand(command)
        command = ""
    }

    if (showEula) {
        AlertDialog(
            onDismissRequest = { showEula = false },
            title = { Text("Minecraft EULA") },
            text = {
                Text(
                    "To run a Minecraft server you must agree to the Minecraft EULA. " +
                        "Read it at aka.ms/MinecraftEULA. Tap I agree if you accept it."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    prefs.putEulaAccepted(true)
                    showEula = false
                    server.start()
                }) { Text("I agree") }
            },
            dismissButton = {
                TextButton(onClick = { showEula = false }) { Text("Cancel") }
            }
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("Server", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            // ---------------- Status ----------------
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(dot)
                        )
                        Spacer(Modifier.size(10.dp))
                        Text(title, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (running) "${server.players} online · ${prefs.ramMb} MB memory" else server.status,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (server.progress >= 0f) {
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = server.progress,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (stopped) {
                            Button(onClick = {
                                prefs.putMcVersion(versionText)
                                if (prefs.eulaAccepted) server.start() else showEula = true
                            }) { Text("Start server") }
                        } else {
                            Button(
                                onClick = { server.stop() },
                                enabled = state != ServerManager.State.Stopping
                            ) { Text("Stop server") }
                        }
                        OutlinedButton(
                            onClick = { clipboard.setText(AnnotatedString(server.console.joinToString("\n"))) },
                            enabled = server.console.isNotEmpty()
                        ) { Text("Copy log") }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // ---------------- Console ----------------
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Column(Modifier.verticalScroll(consoleScroll)) {
                    if (server.console.isEmpty()) {
                        Text(
                            "The server console will show here.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    server.console.forEach { text ->
                        Text(
                            text,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = command,
                    onValueChange = { command = it },
                    label = { Text("Command (example: list)") },
                    singleLine = true,
                    enabled = running,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { sendNow() }),
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.size(8.dp))
                Button(onClick = { sendNow() }, enabled = running) { Text("Send") }
            }

            Spacer(Modifier.height(16.dp))

            // ---------------- Address ----------------
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("How to join", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Same Wi-Fi, Java: Add Server, address:",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(server.localAddress(), fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    if (prefs.bedrockEnabled) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Same Wi-Fi, Bedrock: Add Server, address = the numbers before the colon, port 19132.",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Friends in other cities (tunnel):",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val javaAddr = if (prefs.tunnelJavaAddr.isNotEmpty()) prefs.tunnelJavaAddr
                    else tunnel.addresses.firstOrNull() ?: ""
                    if (javaAddr.isEmpty() && prefs.tunnelBedrockAddr.isEmpty()) {
                        Text("Not set up yet.", fontSize = 15.sp)
                    } else {
                        if (javaAddr.isNotEmpty()) Text("Java: $javaAddr", fontSize = 16.sp, fontWeight = FontWeight.Medium)
                        if (prefs.tunnelBedrockAddr.isNotEmpty()) {
                            Text("Bedrock: ${prefs.tunnelBedrockAddr}", fontSize = 16.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = onOpenTunnel) { Text("Open tunnel setup") }
                }
            }

            Spacer(Modifier.height(12.dp))

            // ---------------- Bedrock ----------------
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Let Bedrock players join", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                "Adds Geyser and Floodgate (about 30 MB, downloaded on the next start). Bedrock uses port 19132.",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.size(8.dp))
                        Switch(
                            checked = prefs.bedrockEnabled,
                            onCheckedChange = { prefs.putBedrockEnabled(it) },
                            enabled = stopped
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "The first start with this on restarts once by itself to finish setup.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            // ---------------- Version ----------------
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Minecraft version", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = versionText,
                        onValueChange = { versionText = it },
                        singleLine = true,
                        enabled = stopped,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "VHOST downloads Paper for this version when you start. Java 21 works for 1.20.5 to 1.21.11. " +
                            "With an existing world only change to a newer version, never older.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            // ---------------- Background help ----------------
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Keep it running in the background", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Some phones close background apps. Open the battery list, find VHOST and choose " +
                            "Don't optimise / Unrestricted. Keep the phone plugged in.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = {
                        try {
                            val i = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(i)
                        } catch (e: Exception) {
                            val i = Intent(Settings.ACTION_SETTINGS)
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(i)
                        }
                    }) { Text("Open battery settings") }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
