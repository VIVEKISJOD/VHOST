package com.vhost.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URL
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Runs one Paper Minecraft server as a child process of the app.
 * The foreground service (ServerService) only keeps the app alive and shows the notification.
 */
class ServerManager(
    private val context: Context,
    private val prefs: Prefs,
    private val java: JavaRuntime
) {

    enum class State { Stopped, Preparing, Starting, Running, Stopping }

    var state by mutableStateOf(State.Stopped)
        private set
    var status by mutableStateOf("Offline")
        private set
    /** 0..1 while a file downloads, -1 when no bar should show. */
    var progress by mutableStateOf(-1f)
        private set
    var players by mutableStateOf(0)
        private set
    val console = mutableStateListOf<String>()

    val serverDir = File(context.filesDir, "servers/main")

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var process: Process? = null
    @Volatile private var userStop = false
    @Volatile private var emptySince = 0L
    private var restarts = 0
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun ui(block: () -> Unit) {
        main.post(block)
    }

    // ------------------------------------------------------------------
    // Console and status helpers
    // ------------------------------------------------------------------

    private fun line(text: String) {
        ui {
            console.add(text)
            while (console.size > 400) console.removeAt(0)
        }
    }

    private fun showStatus(text: String, newState: State? = null, bar: Float = -1f) {
        ui {
            status = text
            progress = bar
            if (newState != null) state = newState
            refreshNotification()
        }
    }

    fun clearConsole() {
        console.clear()
    }

    // ------------------------------------------------------------------
    // Public API (call from the main thread)
    // ------------------------------------------------------------------

    fun start() {
        if (state != State.Stopped) return
        if (java.state != JavaRuntime.State.Ready) {
            status = "Set up Java first (Home, Java card)."
            return
        }
        val (_, charging) = batteryInfo()
        if (prefs.onlyWhileCharging && !charging) {
            status = "Plug in the charger first. (Setting: only while charging)"
            return
        }
        if (prefs.onlyOnWifi && !onWifi()) {
            status = "Connect to Wi-Fi first. (Setting: only on Wi-Fi)"
            return
        }
        userStop = false
        restarts = 0
        players = 0
        progress = -1f
        state = State.Preparing
        status = "Getting ready…"
        console.add("---- starting ----")
        ContextCompat.startForegroundService(context, Intent(context, ServerService::class.java))
        acquireLocks()
        thread { runLoop() }
    }

    fun stop() {
        if (state == State.Stopped || state == State.Stopping) return
        userStop = true
        state = State.Stopping
        status = "Stopping… (saving the world)"
        refreshNotification()
        val p = process
        thread {
            if (p != null) {
                sendRaw("stop")
                try {
                    if (!p.waitFor(60, TimeUnit.SECONDS)) {
                        line("Server is slow to stop. Forcing it.")
                        p.destroy()
                        if (!p.waitFor(10, TimeUnit.SECONDS)) p.destroyForcibly()
                    }
                } catch (e: Exception) {
                    // ignore
                }
            }
        }
    }

    fun sendCommand(cmd: String) {
        val c = cmd.trim().removePrefix("/")
        if (c.isEmpty() || state != State.Running) return
        line("> $c")
        sendRaw(c)
    }

    /** Address other devices on the same Wi-Fi can use. */
    fun localAddress(): String {
        return try {
            val ip = NetworkInterface.getNetworkInterfaces().toList()
                .filter { it.isUp && !it.isLoopback }
                .flatMap { it.inetAddresses.toList() }
                .filterIsInstance<Inet4Address>()
                .firstOrNull()?.hostAddress
            if (ip == null) "not connected" else "$ip:${prefs.port}"
        } catch (e: Exception) {
            "unknown"
        }
    }

    fun buildNotification(): Notification {
        ensureChannels()
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val stopIntent = PendingIntent.getService(
            context, 1,
            Intent(context, ServerService::class.java).setAction(ServerService.ACTION_STOP),
            flags
        )
        val openIntent = PendingIntent.getActivity(
            context, 2,
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags
        )
        val text = when (state) {
            State.Running -> "Running · ${players} online · port ${prefs.port}"
            State.Stopping -> "Stopping…"
            State.Stopped -> "Offline"
            else -> status
        }
        return NotificationCompat.Builder(context, CH_RUN)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("VHOST server")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openIntent)
            .addAction(0, "Stop", stopIntent)
            .build()
    }

    // ------------------------------------------------------------------
    // Main loop (background thread)
    // ------------------------------------------------------------------

    private fun runLoop() {
        var error = ""
        try {
            prepareFiles()
            if (!userStop) {
                while (true) {
                    val code = launchAndWait()
                    if (userStop) break
                    if (code == 0) break
                    if (prefs.notifyCrash) postEvent(3, "Server crashed", "Exit code $code")
                    if (prefs.autoRestartOnCrash && restarts < 3) {
                        restarts++
                        line("Server stopped (code $code). Restarting in 10 seconds ($restarts of 3)…")
                        showStatus("Restarting soon…", State.Starting)
                        var waited = 0
                        while (waited < 10 && !userStop) {
                            Thread.sleep(1000)
                            waited++
                        }
                        if (userStop) break
                    } else {
                        error = "Server stopped unexpectedly (code $code). See the console."
                        break
                    }
                }
            }
        } catch (e: Exception) {
            if (!userStop) {
                error = e.message ?: e.javaClass.simpleName
                line("ERROR: $error")
            }
        }
        finish(error)
    }

    private fun finish(error: String) {
        process = null
        releaseLocks()
        ui {
            state = State.Stopped
            players = 0
            progress = -1f
            status = if (error.isEmpty()) "Offline" else error
            context.stopService(Intent(context, ServerService::class.java))
            notificationManager.cancel(ServerService.NOTIF_ID)
        }
    }

    private fun prepareFiles() {
        serverDir.mkdirs()
        val version = prefs.mcVersion.trim()
        if (version.isEmpty()) throw IllegalStateException("Type a Minecraft version first.")
        val jar = File(serverDir, "paper.jar")
        val marker = File(serverDir, "paper.version")
        if (!jar.exists() || !marker.exists() || marker.readText().trim() != version) {
            marker.delete()
            showStatus("Finding Paper $version…", State.Preparing)
            val found = findPaper(version)
            line("Paper $version build ${found.second}")
            showStatus("Downloading Paper $version…", State.Preparing, 0f)
            val part = File(serverDir, "paper.jar.part")
            download(found.first, part)
            jar.delete()
            if (!part.renameTo(jar)) throw IOException("Could not save paper.jar")
            marker.writeText(version)
        }
        if (userStop) return
        // The user accepted the Minecraft EULA in the app before the first start.
        File(serverDir, "eula.txt").writeText("# Accepted in VHOST\neula=true\n")
        writeProperties()
    }

    private fun writeProperties() {
        val f = File(serverDir, "server.properties")
        val lines = if (f.exists()) {
            f.readLines().toMutableList()
        } else {
            mutableListOf("motd=VHOST server", "view-distance=6", "simulation-distance=4")
        }
        fun put(key: String, value: String) {
            val i = lines.indexOfFirst { it.startsWith("$key=") }
            if (i >= 0) lines[i] = "$key=$value" else lines.add("$key=$value")
        }
        put("server-port", prefs.port.toString())
        put("max-players", prefs.maxPlayers.toString())
        f.writeText(lines.joinToString("\n") + "\n")
    }

    /** Returns the download link and build number of the newest stable Paper build. */
    private fun findPaper(version: String): Pair<String, Int> {
        val conn = open("https://fill.papermc.io/v3/projects/paper/versions/$version/builds", true)
        val body = conn.inputStream.bufferedReader().use { it.readText() }.trim()
        if (!body.startsWith("[")) throw IOException("Paper has no builds for $version.")
        val arr = JSONArray(body)
        var bestUrl = ""
        var bestId = -1
        var anyUrl = ""
        var anyId = -1
        for (i in 0 until arr.length()) {
            val b = arr.getJSONObject(i)
            val id = b.optInt("id", -1)
            val url = b.optJSONObject("downloads")
                ?.optJSONObject("server:default")
                ?.optString("url", "") ?: ""
            if (url.isEmpty()) continue
            if (id > anyId) {
                anyId = id
                anyUrl = url
            }
            if (b.optString("channel") == "STABLE" && id > bestId) {
                bestId = id
                bestUrl = url
            }
        }
        if (bestUrl.isNotEmpty()) return Pair(bestUrl, bestId)
        if (anyUrl.isNotEmpty()) return Pair(anyUrl, anyId)
        throw IOException("Paper has no download for $version.")
    }

    private fun open(url: String, paper: Boolean = false): HttpURLConnection {
        var current = url
        var hops = 0
        while (true) {
            val c = URL(current).openConnection() as HttpURLConnection
            c.connectTimeout = 20000
            c.readTimeout = 60000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", USER_AGENT)
            c.setRequestProperty("Accept-Encoding", "identity")
            val code = c.responseCode
            if (code in 301..308 && code != 304) {
                val loc = c.getHeaderField("Location") ?: throw IOException("redirect without address")
                c.disconnect()
                current = URL(URL(current), loc).toString()
                hops++
                if (hops > 8) throw IOException("too many redirects")
                continue
            }
            if (code == 404 && paper) throw IOException("Paper has no version called that. Check the version number.")
            if (code != 200) throw IOException("download server answered $code")
            return c
        }
    }

    private fun download(url: String, dest: File) {
        val conn = open(url)
        val total = conn.contentLengthLong
        var done = 0L
        var lastShown = 0L
        conn.inputStream.use { input ->
            FileOutputStream(dest).use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    if (userStop) throw IOException("cancelled")
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    val now = System.currentTimeMillis()
                    if (total > 0 && now - lastShown > 300) {
                        lastShown = now
                        showStatus("Downloading Paper… ${done / 1_000_000} MB", State.Preparing, done.toFloat() / total)
                    }
                }
            }
        }
        if (total > 0 && dest.length() < total) throw IOException("download was cut, try again")
    }

    /** Starts the server and blocks until it exits. Returns the exit code. */
    private fun launchAndWait(): Int {
        val javaBin = java.javaBinary() ?: throw IllegalStateException("Java was not found. Set it up again.")
        val ram = prefs.ramMb
        val tmp = File(context.filesDir, "tmp")
        tmp.mkdirs()
        val cmd = listOf(
            javaBin.absolutePath,
            "-Xms${minOf(512, ram)}M",
            "-Xmx${ram}M",
            "-XX:+UseSerialGC",
            "-XX:-UsePerfData",
            "-Djava.io.tmpdir=${tmp.absolutePath}",
            "-Dfile.encoding=UTF-8",
            "-Djava.net.preferIPv4Stack=true",
            "-Dterminal.jline=false",
            "-jar", "paper.jar",
            "nogui"
        )
        val pb = ProcessBuilder(cmd)
        pb.environment().putAll(java.environment())
        pb.directory(serverDir)
        pb.redirectErrorStream(true)
        showStatus("Starting… the first start takes a few minutes.", State.Starting)
        val p = pb.start()
        process = p
        emptySince = System.currentTimeMillis()
        if (userStop) sendRaw("stop")
        startMonitor(p)

        val ansi = Regex("\u001B\\[[0-9;?]*[A-Za-z]")
        val joined = Regex(": (\\S+) joined the game")
        val left = Regex(": (\\S+) left the game")
        p.inputStream.bufferedReader().use { r ->
            while (true) {
                val raw = r.readLine() ?: break
                val text = ansi.replace(raw, "").replace("\r", "")
                if (text.isBlank()) continue
                line(text)
                if (text.contains("Done (") && text.contains("For help, type")) {
                    emptySince = System.currentTimeMillis()
                    ui {
                        state = State.Running
                        status = "Running"
                        progress = -1f
                        refreshNotification()
                    }
                    if (prefs.notifyStarted) postEvent(1, "Server is online", "Port ${prefs.port}")
                    continue
                }
                val j = joined.find(text)
                if (j != null) {
                    ui { players += 1; refreshNotification() }
                    if (prefs.notifyPlayerJoin) postEvent(2, "Player joined", j.groupValues[1])
                    continue
                }
                if (left.containsMatchIn(text)) {
                    ui {
                        if (players > 0) players -= 1
                        if (players == 0) emptySince = System.currentTimeMillis()
                        refreshNotification()
                    }
                }
            }
        }
        val code = p.waitFor()
        line("---- server stopped (code $code) ----")
        process = null
        return code
    }

    private fun sendRaw(c: String) {
        val p = process ?: return
        thread {
            try {
                p.outputStream.write((c + "\n").toByteArray())
                p.outputStream.flush()
            } catch (e: Exception) {
                // server already closed
            }
        }
    }

    /** Checks battery, Wi-Fi and empty-server rules every 30 seconds while the server runs. */
    private fun startMonitor(p: Process) {
        val t = thread(isDaemon = true) {
            while (p.isAlive) {
                try {
                    Thread.sleep(30_000)
                } catch (e: InterruptedException) {
                    return@thread
                }
                if (!p.isAlive || userStop) return@thread
                val (level, charging) = batteryInfo()
                var reason = ""
                if (prefs.stopOnLowBattery && !charging && level <= prefs.lowBatteryPercent) {
                    reason = "Battery is at $level%. Stopping the server to protect the world."
                } else if (prefs.onlyWhileCharging && !charging) {
                    reason = "Charger unplugged. Stopping the server. (Setting: only while charging)"
                } else if (prefs.onlyOnWifi && !onWifi()) {
                    reason = "Wi-Fi lost. Stopping the server. (Setting: only on Wi-Fi)"
                } else if (prefs.autoStopWhenEmpty && state == State.Running && players == 0 &&
                    System.currentTimeMillis() - emptySince > prefs.emptyStopMinutes * 60_000L
                ) {
                    reason = "No players for ${prefs.emptyStopMinutes} minutes. Stopping the server."
                }
                if (reason.isNotEmpty()) {
                    line(reason)
                    ui { stop() }
                    return@thread
                }
            }
        }
        t.name = "vhost-monitor"
    }

    // ------------------------------------------------------------------
    // Phone state, locks and notifications
    // ------------------------------------------------------------------

    private fun batteryInfo(): Pair<Int, Boolean> {
        val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 100) ?: 100
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val plugged = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        return Pair(level * 100 / maxOf(scale, 1), plugged != 0)
    }

    private fun onWifi(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))
        } catch (e: Exception) {
            false
        }
    }

    private fun acquireLocks() {
        if (!prefs.keepAwake) return
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "vhost:server")
            wl.setReferenceCounted(false)
            wl.acquire()
            wakeLock = wl
            val wm = context.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val fl = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "vhost:wifi")
            fl.setReferenceCounted(false)
            fl.acquire()
            wifiLock = fl
        } catch (e: Exception) {
            // locks are a bonus, the server can still run
        }
    }

    private fun releaseLocks() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
            wifiLock?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
            // ignore
        }
        wakeLock = null
        wifiLock = null
    }

    private fun ensureChannels() {
        notificationManager.createNotificationChannel(
            NotificationChannel(CH_RUN, "Server running", NotificationManager.IMPORTANCE_LOW)
        )
        notificationManager.createNotificationChannel(
            NotificationChannel(CH_EVENTS, "Server alerts", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    private fun refreshNotification() {
        if (state == State.Stopped) return
        try {
            notificationManager.notify(ServerService.NOTIF_ID, buildNotification())
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun postEvent(id: Int, title: String, text: String) {
        try {
            ensureChannels()
            val n = NotificationCompat.Builder(context, CH_EVENTS)
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .build()
            notificationManager.notify(100 + id, n)
        } catch (e: Exception) {
            // ignore
        }
    }

    companion object {
        private const val CH_RUN = "vhost_run"
        private const val CH_EVENTS = "vhost_events"
        private const val USER_AGENT = "VHOST/1.0 (https://github.com/VIVEKISJOD/VHOST)"
    }
}
