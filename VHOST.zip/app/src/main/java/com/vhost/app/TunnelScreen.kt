package com.vhost.app

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun TunnelScreen(tunnel: TunnelManager, prefs: Prefs, onBack: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var javaText by remember { mutableStateOf(prefs.tunnelJavaAddr) }
    var bedrockText by remember { mutableStateOf(prefs.tunnelBedrockAddr) }
    var keyText by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { tunnel.refresh() }

    val logScroll = rememberScrollState()
    LaunchedEffect(tunnel.log.size) {
        logScroll.scrollTo(logScroll.maxValue)
    }

    val state = tunnel.state
    val busy = state == TunnelManager.State.Installing || state == TunnelManager.State.Starting
    val installed = state == TunnelManager.State.Ready ||
        state == TunnelManager.State.Starting ||
        state == TunnelManager.State.Running ||
        (state == TunnelManager.State.Failed && tunnel.binary() != null)

    fun openLink(url: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)
        } catch (e: Exception) {
            // no browser
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("Friends tunnel", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            // ---------------- Status ----------------
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        when (state) {
                            TunnelManager.State.NotInstalled -> "Tunnel not set up"
                            TunnelManager.State.Installing -> "Installing the tunnel program"
                            TunnelManager.State.Ready -> "Tunnel is off"
                            TunnelManager.State.Starting -> "Starting the tunnel"
                            TunnelManager.State.Running -> "Tunnel is running"
                            TunnelManager.State.Failed -> "Tunnel problem"
                        },
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "A tunnel (playit.gg, free account) gives your server an internet address, so friends in other cities can join without being on your Wi-Fi. " +
                            "If something fails, tap Copy log and send it to me.",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (state == TunnelManager.State.Installing) {
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (!installed) {
                            Button(onClick = { tunnel.install() }, enabled = !busy) {
                                Text("Install tunnel")
                            }
                        } else if (state == TunnelManager.State.Running || state == TunnelManager.State.Starting) {
                            Button(onClick = { tunnel.stop() }) { Text("Stop tunnel") }
                        } else {
                            Button(onClick = { tunnel.start() }) { Text("Start tunnel") }
                        }
                        OutlinedButton(
                            onClick = { clipboard.setText(AnnotatedString(tunnel.log.joinToString("\n"))) },
                            enabled = tunnel.log.isNotEmpty()
                        ) { Text("Copy log") }
                    }
                }
            }

            // ---------------- Claim link ----------------
            if (tunnel.claimUrl.isNotEmpty() && !tunnel.linked) {
                Spacer(Modifier.height(12.dp))
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Step: link your free account", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Tap the button, sign in or sign up on playit.gg, and approve this device. Then come back here.",
                            fontSize = 14.sp
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { openLink(tunnel.claimUrl) }) { Text("Open link") }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // ---------------- Account key (backup way) ----------------
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        if (tunnel.linked) "Account linked" else "Account not linked yet",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(4.dp))
                    if (tunnel.linked) {
                        Text(
                            "Your free playit.gg account is linked to this device.",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = { tunnel.unlink() },
                            enabled = state != TunnelManager.State.Running && state != TunnelManager.State.Starting
                        ) { Text("Unlink account") }
                    } else {
                        Text(
                            "Tap Start tunnel to get a link. If the link does not work, make a secret key on playit.gg " +
                                "(Agents, add agent) and paste it here.",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = keyText,
                            onValueChange = { keyText = it },
                            label = { Text("Secret key (optional)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                tunnel.saveSecret(keyText)
                                keyText = ""
                            },
                            enabled = keyText.isNotBlank()
                        ) { Text("Save key") }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // ---------------- Steps after linking ----------------
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("After linking", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "On playit.gg open Tunnels and add two tunnels for this device: " +
                            "Minecraft Java (local port 25565) and Minecraft Bedrock (local port 19132). " +
                            "Copy the addresses it gives you into the boxes below, and send them to your friends.",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { openLink("https://playit.gg/account/tunnels") }) {
                        Text("Open playit.gg tunnels")
                    }
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = javaText,
                        onValueChange = {
                            javaText = it
                            prefs.putTunnelJavaAddr(it)
                        },
                        label = { Text("Java address") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = bedrockText,
                        onValueChange = {
                            bedrockText = it
                            prefs.putTunnelBedrockAddr(it)
                        },
                        label = { Text("Bedrock address and port") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (tunnel.addresses.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Addresses seen in the log:",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        tunnel.addresses.forEach { a ->
                            Text(a, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Start the tunnel automatically with the server",
                            fontSize = 14.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = prefs.tunnelAutoStart,
                            onCheckedChange = { prefs.putTunnelAutoStart(it) }
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // ---------------- Log ----------------
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Column(Modifier.verticalScroll(logScroll)) {
                    if (tunnel.log.isEmpty()) {
                        Text(
                            "The tunnel log will show here.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    tunnel.log.forEach { line ->
                        Text(
                            line,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
