package com.vhost.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

data class AccentOption(val key: String, val label: String, val color: Color)

val AccentOptions = listOf(
    AccentOption("torch", "Torch", Color(0xFFF2A03D)),
    AccentOption("emerald", "Emerald", Color(0xFF2FCB8A)),
    AccentOption("diamond", "Diamond", Color(0xFF3CC4E8)),
    AccentOption("redstone", "Redstone", Color(0xFFEF5B5B)),
    AccentOption("amethyst", "Amethyst", Color(0xFFA98BF5))
)

fun isDarkTheme(mode: String, system: Boolean): Boolean = when (mode) {
    "dark" -> true
    "light" -> false
    else -> system
}

@Composable
fun VhostTheme(prefs: Prefs, content: @Composable () -> Unit) {
    val dark = isDarkTheme(prefs.theme, isSystemInDarkTheme())
    val accent = AccentOptions.firstOrNull { it.key == prefs.accent }?.color
        ?: AccentOptions[0].color

    val scheme = if (dark) {
        darkColorScheme(
            primary = accent,
            onPrimary = Color(0xFF14181F),
            primaryContainer = accent.copy(alpha = 0.18f),
            onPrimaryContainer = accent,
            background = Color(0xFF14181F),
            onBackground = Color(0xFFE8ECF2),
            surface = Color(0xFF1C222B),
            onSurface = Color(0xFFE8ECF2),
            surfaceVariant = Color(0xFF252C37),
            onSurfaceVariant = Color(0xFF9AA6B5),
            outline = Color(0xFF3A4452),
            outlineVariant = Color(0xFF2C3440),
            error = Color(0xFFFF7A7A)
        )
    } else {
        lightColorScheme(
            primary = accent,
            onPrimary = Color(0xFF14181F),
            primaryContainer = accent.copy(alpha = 0.22f),
            onPrimaryContainer = Color(0xFF14181F),
            background = Color(0xFFF3F4F7),
            onBackground = Color(0xFF14181F),
            surface = Color(0xFFFFFFFF),
            onSurface = Color(0xFF14181F),
            surfaceVariant = Color(0xFFE6E9EE),
            onSurfaceVariant = Color(0xFF566170),
            outline = Color(0xFFB4BCC8),
            outlineVariant = Color(0xFFD9DEE5),
            error = Color(0xFFC62828)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
