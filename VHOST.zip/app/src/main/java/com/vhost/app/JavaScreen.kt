package com.vhost.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun JavaScreen(java: JavaRuntime, onBack: () -> Unit) {
    val installing = java.state == JavaRuntime.State.Installing
    val view = LocalView.current
    val clipboard = LocalClipboardManager.current

    // Keep the screen on while installing so the download is not interrupted.
    DisposableEffect(installing) {
        view.keepScreenOn = installing
        onDispose { view.keepScreenOn = false }
    }

    val logScroll = rememberScrollState()
    LaunchedEffect(java.log.size) {
        logScroll.animateScrollTo(logScroll.maxValue)
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("Java setup", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }

        Column(
            Modifier
                .weight(1f)
                .padding(horizontal = 16.dp)
        ) {
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        when (java.state) {
                            JavaRuntime.State.NotInstalled -> "Java is not installed"
                            JavaRuntime.State.Installing -> "Installing Java"
                            JavaRuntime.State.Ready -> "Java works"
                            JavaRuntime.State.Failed -> "Java setup failed"
                        },
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        when (java.state) {
                            JavaRuntime.State.NotInstalled ->
                                "Minecraft servers need Java. VHOST installs it inside the app. It downloads about 150 MB and needs about 1.5 GB free. Keep VHOST open until it finishes."
                            JavaRuntime.State.Installing ->
                                "Keep VHOST open. This can take a few minutes."
                            else -> java.summary
                        },
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (installing) {
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = java.progress,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { java.install() },
                            enabled = !installing
                        ) {
                            Text(
                                if (java.state == JavaRuntime.State.Ready) "Install again" else "Install Java"
                            )
                        }
                        OutlinedButton(
                            onClick = { clipboard.setText(AnnotatedString(java.log.joinToString("\n"))) },
                            enabled = java.log.isNotEmpty()
                        ) {
                            Text("Copy log")
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant,
                        RoundedCornerShape(10.dp)
                    )
                    .padding(12.dp)
            ) {
                Column(Modifier.verticalScroll(logScroll)) {
                    if (java.log.isEmpty()) {
                        Text(
                            "The install log will show here.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    java.log.takeLast(300).forEach { line ->
                        Text(
                            line,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}
