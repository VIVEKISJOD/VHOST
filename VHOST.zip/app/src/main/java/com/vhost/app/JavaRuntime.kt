package com.vhost.app

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.tukaani.xz.XZInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.file.Files
import java.nio.file.Paths
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream
import kotlin.concurrent.thread

/**
 * Installs a Java runtime that runs on Android (the Termux build of OpenJDK 21)
 * into the app's own storage, then starts it once to prove it works.
 */
class JavaRuntime(private val context: Context) {

    enum class State { NotInstalled, Installing, Ready, Failed }

    var state by mutableStateOf(State.NotInstalled)
        private set
    var summary by mutableStateOf("Not installed")
        private set
    var progress by mutableStateOf(0f)
        private set
    val log = mutableStateListOf<String>()

    val prefix = File(context.filesDir, "usr")
    private val marker = File(prefix, ".vhost_java_ok")
    private val main = Handler(Looper.getMainLooper())

    init {
        if (marker.exists()) {
            state = State.Ready
            summary = marker.readText().trim()
        }
    }

    private class Pkg(val name: String, val filename: String, val size: Long, val depends: List<String>)

    private class LimitedStream(private val src: InputStream, private var left: Long) : InputStream() {
        override fun read(): Int {
            if (left <= 0) return -1
            val r = src.read()
            if (r >= 0) left--
            return r
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (left <= 0) return -1
            val r = src.read(b, off, minOf(len.toLong(), left).toInt())
            if (r > 0) left -= r
            return r
        }
    }

    private fun ui(block: () -> Unit) {
        main.post(block)
    }

    private fun say(text: String) {
        ui {
            text.lines().forEach { if (it.isNotBlank()) log.add(it) }
        }
    }

    // ------------------------------------------------------------------
    // Public API
    // ------------------------------------------------------------------

    fun install() {
        if (state == State.Installing) return
        state = State.Installing
        summary = "Installing…"
        progress = 0f
        log.clear()
        thread {
            try {
                doInstall()
            } catch (e: Exception) {
                say("ERROR: ${e.message ?: e.javaClass.simpleName}")
                ui {
                    state = State.Failed
                    summary = "Failed. See the log."
                }
            }
        }
    }

    /**
     * Installs extra Termux / TUR packages (and what they need) into the same folder as Java.
     * Used for the tunnel program.
     */
    fun installExtra(names: List<String>, log: (String) -> Unit) {
        val arch = termuxArch()
        log("Phone type: $arch")
        var mainBase = ""
        var mainIndex: Map<String, Pkg> = emptyMap()
        for (candidate in BASES) {
            try {
                mainIndex = loadIndex(candidate, arch)
                mainBase = candidate
                break
            } catch (e: Exception) {
                log("  could not use $candidate (${e.message ?: e.javaClass.simpleName})")
            }
        }
        if (mainBase.isEmpty()) {
            throw IllegalStateException("Could not reach the package server. Check your internet.")
        }
        var turIndex: Map<String, Pkg> = emptyMap()
        try {
            turIndex = loadIndex(TUR_BASE, arch, "tur-packages/tur")
        } catch (e: Exception) {
            log("  could not read the extra package list (${e.message ?: e.javaClass.simpleName})")
        }
        log("Package lists loaded.")

        val order = ArrayList<Pair<Pkg, String>>()
        val seen = HashSet<String>()
        fun visit(name: String) {
            if (name in SKIP) return
            val wanted = name in names
            val fromTur = turIndex[name]
            val fromMain = mainIndex[name]
            val p: Pkg?
            val b: String
            if (wanted && fromTur != null || fromMain == null) {
                p = fromTur
                b = TUR_BASE
            } else {
                p = fromMain
                b = mainBase
            }
            if (p == null) {
                log("  skipping $name (not in the list)")
                return
            }
            if (!seen.add(p.name)) return
            for (d in p.depends) visit(d)
            order.add(Pair(p, b))
        }
        for (n in names) visit(n)
        for (n in names) {
            if (order.none { it.first.name == n }) {
                throw IllegalStateException("$n was not found in the package lists.")
            }
        }
        if (order.size > 30) {
            throw IllegalStateException("Too many packages needed (${order.size}). Stopping.")
        }
        log("Need ${order.size} packages: " + order.joinToString(", ") { it.first.name })

        prefix.mkdirs()
        for ((i, pair) in order.withIndex()) {
            val p = pair.first
            log("[${i + 1}/${order.size}] ${p.name}")
            val deb = File(context.cacheDir, "debs/${p.name}.deb")
            deb.parentFile?.mkdirs()
            download(pair.second + p.filename, deb, p.size) { }
            extractDeb(deb)
            deb.delete()
        }
        log("Packages installed.")
    }

    fun jdkDir(): File? {
        val jvm = File(prefix, "lib/jvm")
        return jvm.listFiles()?.firstOrNull { File(it, "bin/java").exists() }
    }

    fun javaBinary(): File? = jdkDir()?.let { File(it, "bin/java") }

    /** Environment needed to start Java from this app. */
    fun environment(): Map<String, String> {
        val jdk = jdkDir()
        val libs = ArrayList<String>()
        libs.add(File(prefix, "lib").absolutePath)
        if (jdk != null) {
            libs.add(File(jdk, "lib").absolutePath)
            libs.add(File(jdk, "lib/server").absolutePath)
            libs.add(File(jdk, "lib/jli").absolutePath)
        }
        val home = File(context.filesDir, "home")
        home.mkdirs()
        val tmp = File(context.filesDir, "tmp")
        tmp.mkdirs()
        return mapOf(
            "LD_LIBRARY_PATH" to libs.joinToString(":"),
            "HOME" to home.absolutePath,
            "TMPDIR" to tmp.absolutePath,
            "PREFIX" to prefix.absolutePath,
            "JAVA_HOME" to (jdk?.absolutePath ?: ""),
            "PATH" to File(prefix, "bin").absolutePath + ":/system/bin",
            "LANG" to "en_US.UTF-8"
        )
    }

    // ------------------------------------------------------------------
    // Install steps
    // ------------------------------------------------------------------

    private fun doInstall() {
        val free = context.filesDir.usableSpace
        if (free < 1_500_000_000L) {
            throw IllegalStateException("Not enough free space. About 1.5 GB is needed.")
        }

        say("Cleaning old files…")
        removeAll(prefix)

        val arch = termuxArch()
        say("Phone type: $arch")

        say("Reading the package list…")
        var base = ""
        var index: Map<String, Pkg> = emptyMap()
        var lastError = ""
        for (candidate in BASES) {
            try {
                index = loadIndex(candidate, arch)
                base = candidate
                break
            } catch (e: Exception) {
                lastError = e.message ?: e.javaClass.simpleName
                say("  could not use $candidate ($lastError)")
            }
        }
        if (base.isEmpty()) {
            throw IllegalStateException("Could not reach the package server. Check your internet and try again.")
        }
        say("Package list loaded (${index.size} entries).")

        val order = ArrayList<Pkg>()
        val seen = HashSet<String>()
        fun visit(name: String) {
            if (name in SKIP) return
            val p = index[name]
            if (p == null) {
                say("  skipping $name (not in the list)")
                return
            }
            if (!seen.add(p.name)) return
            for (d in p.depends) visit(d)
            order.add(p)
        }
        visit("openjdk-21")
        if (order.none { it.name == "openjdk-21" }) {
            throw IllegalStateException("openjdk-21 was not found in the package list.")
        }
        if (order.size > 40) {
            throw IllegalStateException("Too many packages needed (${order.size}). Stopping to protect your storage.")
        }
        say("Need ${order.size} packages: " + order.joinToString(", ") { it.name })

        prefix.mkdirs()
        for ((i, p) in order.withIndex()) {
            say("[${i + 1}/${order.size}] ${p.name}")
            val deb = File(context.cacheDir, "debs/${p.name}.deb")
            deb.parentFile?.mkdirs()
            var lastPercent = -1
            download(base + p.filename, deb, p.size) { frac ->
                val percent = (frac * 100).toInt()
                if (percent != lastPercent) {
                    lastPercent = percent
                    ui { progress = (i + frac) / order.size }
                }
            }
            say("  unpacking…")
            extractDeb(deb)
            deb.delete()
        }

        say("Starting Java to test it…")
        val out = runVersion()
        say(out)
        if (!out.contains("version")) {
            throw IllegalStateException("Java did not start. Send me this log.")
        }
        val first = out.lines().firstOrNull { it.isNotBlank() } ?: "Java installed"
        marker.writeText(first)
        ui {
            state = State.Ready
            summary = first
            progress = 1f
        }
        say("Done. Java works on this device.")
    }

    private fun termuxArch(): String {
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: ""
        return when {
            abi.startsWith("arm64") -> "aarch64"
            abi.startsWith("armeabi") -> "arm"
            abi == "x86_64" -> "x86_64"
            abi == "x86" -> "i686"
            else -> throw IllegalStateException("This processor ($abi) is not supported.")
        }
    }

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 40000
        c.setRequestProperty("User-Agent", "VHOST-App")
        c.instanceFollowRedirects = true
        if (c.responseCode != 200) {
            throw IllegalStateException("HTTP ${c.responseCode}")
        }
        return c
    }

    private fun parseDeps(s: String): List<String> {
        return s.split(",").mapNotNull { item ->
            val first = item.split("|")[0].trim()
            val n = first.substringBefore("(").trim().substringBefore(":").trim()
            if (n.isEmpty()) null else n
        }
    }

    private fun loadIndex(base: String, arch: String, dist: String = "stable/main"): Map<String, Pkg> {
        val map = HashMap<String, Pkg>()
        val url = base + "dists/$dist/binary-$arch/Packages"
        var gz = false
        val conn = try {
            open(url)
        } catch (e: Exception) {
            gz = true
            open("$url.gz")
        }
        val stream: InputStream = if (gz) GZIPInputStream(conn.inputStream) else conn.inputStream
        stream.bufferedReader().use { r ->
            var name = ""
            var file = ""
            var size = 0L
            var deps = ""
            var prov = ""
            var lastKey = ""

            fun flush() {
                if (name.isNotEmpty() && file.isNotEmpty()) {
                    val p = Pkg(name, file, size, parseDeps(deps))
                    map[name] = p
                    for (v in prov.split(",")) {
                        val n = v.trim().substringBefore(" ").substringBefore("(")
                        if (n.isNotEmpty() && !map.containsKey(n)) map[n] = p
                    }
                }
                name = ""
                file = ""
                size = 0L
                deps = ""
                prov = ""
                lastKey = ""
            }

            while (true) {
                val line = r.readLine() ?: break
                if (line.isEmpty()) {
                    flush()
                    continue
                }
                if (line[0] == ' ' || line[0] == '\t') {
                    if (lastKey == "Depends") deps += " " + line.trim()
                    continue
                }
                val i = line.indexOf(':')
                if (i < 0) continue
                val key = line.substring(0, i)
                val value = line.substring(i + 1).trim()
                lastKey = key
                when (key) {
                    "Package" -> name = value
                    "Filename" -> file = value
                    "Size" -> size = value.toLongOrNull() ?: 0L
                    "Depends" -> deps = value
                    "Provides" -> prov = value
                }
            }
            flush()
        }
        return map
    }

    private fun download(url: String, dest: File, expected: Long, onProgress: (Float) -> Unit) {
        val conn = open(url)
        val total = if (conn.contentLengthLong > 0) conn.contentLengthLong else expected
        var done = 0L
        conn.inputStream.use { input ->
            FileOutputStream(dest).use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) onProgress(minOf(1f, done.toFloat() / total.toFloat()))
                }
            }
        }
    }

    private fun readFully(input: InputStream, b: ByteArray): Int {
        var total = 0
        while (total < b.size) {
            val r = input.read(b, total, b.size - total)
            if (r < 0) break
            total += r
        }
        return total
    }

    private fun skipFully(input: InputStream, n: Long) {
        var left = n
        val buf = ByteArray(8192)
        while (left > 0) {
            val r = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (r < 0) break
            left -= r
        }
    }

    /** A .deb is an "ar" archive. We only need the data.tar.* part inside it. */
    private fun extractDeb(deb: File) {
        FileInputStream(deb).use { fin ->
            val input = BufferedInputStream(fin, 64 * 1024)
            val magic = ByteArray(8)
            readFully(input, magic)
            if (String(magic) != "!<arch>\n") {
                throw IllegalStateException("${deb.name} is not a package file.")
            }
            val header = ByteArray(60)
            while (true) {
                val n = readFully(input, header)
                if (n < 60) break
                val name = String(header, 0, 16).trim().trimEnd('/')
                val size = String(header, 48, 10).trim().toLong()
                if (name.startsWith("data.tar")) {
                    val limited = LimitedStream(input, size)
                    val decoded: InputStream = when {
                        name.endsWith(".xz") -> XZInputStream(limited)
                        name.endsWith(".gz") -> GZIPInputStream(limited)
                        name == "data.tar" -> limited
                        else -> throw IllegalStateException("Unsupported package format: $name")
                    }
                    untar(decoded)
                    return
                }
                skipFully(input, size + (size % 2))
            }
            throw IllegalStateException("No files found inside ${deb.name}.")
        }
    }

    private fun relPath(raw: String): String? {
        var n = raw
        if (n.startsWith("./")) n = n.substring(2)
        n = n.trimStart('/')
        if (!n.startsWith(TERMUX_ROOT)) return null
        return n.removePrefix(TERMUX_ROOT).trimStart('/')
    }

    private fun untar(stream: InputStream) {
        val rootPath = prefix.toPath().normalize()
        TarArchiveInputStream(BufferedInputStream(stream, 64 * 1024)).use { tar ->
            while (true) {
                val e: TarArchiveEntry = tar.nextTarEntry ?: break
                val rel = relPath(e.name) ?: continue
                val dest = File(prefix, rel)
                if (!dest.toPath().normalize().startsWith(rootPath)) continue
                when {
                    e.isDirectory -> dest.mkdirs()
                    e.isSymbolicLink -> {
                        dest.parentFile?.mkdirs()
                        dest.delete()
                        var target = e.linkName
                        if (target.startsWith("/$TERMUX_ROOT")) {
                            target = prefix.absolutePath + target.removePrefix("/$TERMUX_ROOT")
                        }
                        Files.createSymbolicLink(dest.toPath(), Paths.get(target))
                    }
                    e.isLink -> {
                        val src = relPath(e.linkName)
                        if (src != null) {
                            dest.parentFile?.mkdirs()
                            dest.delete()
                            File(prefix, src).copyTo(dest, overwrite = true)
                            fixPermissions(dest, e.mode)
                        }
                    }
                    e.isFile -> {
                        dest.parentFile?.mkdirs()
                        dest.delete()
                        FileOutputStream(dest).use { out -> tar.copyTo(out) }
                        fixPermissions(dest, e.mode)
                    }
                    else -> {}
                }
            }
        }
    }

    private fun fixPermissions(f: File, mode: Int) {
        f.setReadable(true, false)
        f.setWritable(true, true)
        if ((mode and 0x49) != 0) f.setExecutable(true, false)
    }

    private fun removeAll(dir: File) {
        if (!dir.exists() && !isLink(dir)) return
        try {
            val p = ProcessBuilder("/system/bin/rm", "-rf", dir.absolutePath).start()
            p.waitFor(120, TimeUnit.SECONDS)
        } catch (e: Exception) {
            dir.deleteRecursively()
        }
    }

    private fun isLink(f: File): Boolean = Files.isSymbolicLink(f.toPath())

    private fun runVersion(): String {
        val java = javaBinary() ?: throw IllegalStateException("The Java program was not found after installing.")
        java.setExecutable(true, false)
        val env = environment()
        val pb = ProcessBuilder(java.absolutePath, "-version")
        pb.environment().putAll(env)
        pb.directory(File(context.filesDir, "home"))
        pb.redirectErrorStream(true)
        val p = pb.start()
        val text = p.inputStream.bufferedReader().readText()
        p.waitFor(20, TimeUnit.SECONDS)
        return text.trim()
    }

    companion object {
        private val BASES = listOf(
            "https://packages-cf.termux.dev/apt/termux-main/",
            "https://packages.termux.dev/apt/termux-main/"
        )
        private const val TUR_BASE = "https://tur.kcubeterm.com/"
        private const val TERMUX_ROOT = "data/data/com.termux/files/usr"
        private val SKIP = setOf(
            "termux-exec", "termux-tools", "termux-keyring", "termux-licenses",
            "apt", "dpkg", "bash", "coreutils", "busybox"
        )
    }
}
