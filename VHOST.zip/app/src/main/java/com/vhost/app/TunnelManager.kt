package com.vhost.app

import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Runs the playit.gg program (Termux build) so friends in other cities can join.
 *
 * The new playit (1.x) has different flags than the old one and prints nothing
 * by itself, so this class:
 *  - reads the program's own --help and picks the flags it really has,
 *  - links the free account itself (claim link, no terminal needed),
 *  - asks playit's web API for the public addresses.
 * Everything is kept in a log so problems can be read and copied.
 */
class TunnelManager(
    private val context: android.content.Context,
    private val prefs: Prefs,
    private val java: JavaRuntime
) {

    enum class State { NotInstalled, Installing, Ready, Starting, Running, Failed }

    private class Attempt(val args: List<String>, val env: Map<String, String>)

    var state by mutableStateOf(State.NotInstalled)
        private set
    var claimUrl by mutableStateOf("")
        private set
    var linked by mutableStateOf(false)
        private set
    val addresses = mutableStateListOf<String>()
    val log = mutableStateListOf<String>()

    private val dir = File(context.filesDir, "tunnel")
    private val secretFile = File(dir, "playit.toml")
    private val keyFile = File(dir, "playit.key")
    private val socketFile = File(dir, "playit.sock")
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var process: Process? = null
    @Volatile private var stopping = false
    @Volatile private var startedByServer = false

    init {
        refresh()
    }

    private fun ui(block: () -> Unit) {
        main.post(block)
    }

    private fun say(text: String) {
        ui {
            text.lines().forEach { if (it.isNotBlank()) log.add(it) }
            while (log.size > 400) log.removeAt(0)
        }
    }

    fun binary(): File? {
        return listOf("playitd", "playit-cli", "playit")
            .map { File(java.prefix, "bin/$it") }
            .firstOrNull { it.exists() }
    }

    fun hasSecret(): Boolean = readKey() != null

    private fun readKey(): String? {
        try {
            if (secretFile.exists()) {
                val m = Regex("secret_key\\s*=\\s*\"([^\"]+)\"").find(secretFile.readText())
                if (m != null) return m.groupValues[1]
            }
            if (keyFile.exists()) {
                val t = keyFile.readText().trim()
                if (t.isNotEmpty()) return t
            }
        } catch (e: Exception) {
            // unreadable: treat as not linked
        }
        return null
    }

    private fun writeSecret(key: String) {
        dir.mkdirs()
        secretFile.writeText("secret_key = \"" + key + "\"\n")
        keyFile.writeText(key)
        ui { linked = true }
    }

    /** The user pasted a secret key made on the playit.gg website. */
    fun saveSecret(raw: String) {
        val key = raw.trim().replace("\"", "").replace("secret_key", "").replace("=", "").trim()
        if (key.length < 8) {
            say("That key looks too short. Copy the whole secret key from playit.gg.")
            return
        }
        try {
            writeSecret(key)
            claimUrl = ""
            say("Secret key saved. Now tap Start tunnel.")
        } catch (e: Exception) {
            say("ERROR: could not save the key (${e.message ?: e.javaClass.simpleName})")
        }
    }

    /** Forget the linked account (to link another one). */
    fun unlink() {
        if (state == State.Starting || state == State.Running) return
        secretFile.delete()
        keyFile.delete()
        linked = false
        claimUrl = ""
        say("Account unlinked.")
    }

    /** Call when the screen opens, to notice if the files were removed. */
    fun refresh() {
        linked = hasSecret()
        if (state == State.Installing || state == State.Starting || state == State.Running) return
        state = if (binary() != null) State.Ready else State.NotInstalled
    }

    fun install() {
        if (state == State.Installing || state == State.Starting || state == State.Running) return
        state = State.Installing
        log.clear()
        thread {
            try {
                java.installExtra(listOf("playit", "ca-certificates"), setOf("ca-certificates")) { say(it) }
                val bin = binary() ?: throw IllegalStateException("The playit program was not found after installing.")
                val found = (File(java.prefix, "bin").listFiles() ?: emptyArray<File>())
                    .filter { it.name.startsWith("playit") }
                    .sortedBy { it.name }
                found.forEach { it.setExecutable(true, false) }
                say("Programs found: " + found.joinToString(", ") { it.name })
                say("Using: ${bin.name}")
                for (f in found.take(3)) {
                    say("--- ${f.name} --help ---")
                    say(runQuick(f, listOf("--help")))
                }
                ui { state = State.Ready }
            } catch (e: Exception) {
                say("ERROR: ${e.message ?: e.javaClass.simpleName}")
                ui { state = State.Failed }
            }
        }
    }

    fun start(byServer: Boolean = false) {
        if (state != State.Ready && state != State.Failed) return
        val bin = binary()
        if (bin == null) {
            say("Install the tunnel first.")
            return
        }
        startedByServer = byServer
        stopping = false
        state = State.Starting
        thread {
            try {
                var key = readKey()
                if (key == null) {
                    if (byServer) {
                        say("Link your playit account first: open Friends tunnel and tap Start tunnel.")
                        ui { state = State.Failed }
                        return@thread
                    }
                    key = claimSecret()
                    if (key == null) {
                        ui { state = if (stopping) State.Ready else State.Failed }
                        return@thread
                    }
                    writeSecret(key)
                    ui { claimUrl = "" }
                    say("Account linked.")
                }
                runAttempts(bin, key)
            } catch (e: Exception) {
                say("ERROR: ${e.message ?: e.javaClass.simpleName}")
                ui { state = State.Failed }
            }
        }
    }

    /** Called when the server is online: start the tunnel if it is set up and the setting is on. */
    fun autoStart() {
        if (prefs.tunnelAutoStart && hasSecret() && binary() != null) start(true)
    }

    /** Called when the server stops. */
    fun autoStop() {
        if (startedByServer) stop()
    }

    fun stop() {
        stopping = true
        val p = process ?: return
        thread {
            p.destroy()
            try {
                if (!p.waitFor(5, TimeUnit.SECONDS)) p.destroyForcibly()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    // ------------------------------------------------------------------

    private fun env(): Map<String, String> {
        val e = HashMap(java.environment())
        val cert = File(java.prefix, "etc/tls/cert.pem")
        if (cert.exists()) {
            e["SSL_CERT_FILE"] = cert.absolutePath
            e["SSL_CERT_DIR"] = File(java.prefix, "etc/tls").absolutePath
        }
        return e
    }

    /** Full text printed by a short command (used for --help). */
    private fun runRaw(bin: File, args: List<String>): String {
        val pb = ProcessBuilder(listOf(bin.absolutePath) + args)
        pb.environment().putAll(env())
        dir.mkdirs()
        pb.directory(dir)
        pb.redirectErrorStream(true)
        val p = pb.start()
        val text = p.inputStream.bufferedReader().readText()
        p.waitFor(15, TimeUnit.SECONDS)
        return text
    }

    private fun runQuick(bin: File, args: List<String>): String {
        return try {
            runRaw(bin, args).trim().lines().take(40).joinToString("\n")
        } catch (e: Exception) {
            "(could not run: ${e.message ?: e.javaClass.simpleName})"
        }
    }

    // ------------------------------------------------------------------
    // Account link (claim) through playit's web API

    private fun randomHex(bytes: Int): String {
        val b = ByteArray(bytes)
        SecureRandom().nextBytes(b)
        return b.joinToString("") { String.format("%02x", it) }
    }

    private fun httpPost(url: String, body: String, agentKey: String? = null): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("User-Agent", "VHOST/1.0 (https://github.com/VIVEKISJOD/VHOST)")
            if (agentKey != null) c.setRequestProperty("Authorization", "Agent-Key " + agentKey)
            c.doOutput = true
            c.outputStream.use { it.write(body.toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            return stream?.bufferedReader()?.readText() ?: ""
        } finally {
            c.disconnect()
        }
    }

    /** Shows a link, waits until the user approves it on playit.gg, returns the secret key (or null). */
    private fun claimSecret(): String? {
        val code = randomHex(5)
        val url = "https://playit.gg/claim/" + code
        ui { claimUrl = url }
        say("Tap Open link below, sign in on playit.gg and approve.")
        say(url)
        val begun = System.currentTimeMillis()
        var last = ""
        while (!stopping && System.currentTimeMillis() - begun < 10 * 60_000L) {
            var res = ""
            try {
                res = httpPost(
                    "https://api.playit.gg/claim/setup",
                    "{\"code\":\"" + code + "\",\"agent_type\":\"self-managed\",\"version\":\"1.0.10\"}"
                )
            } catch (e: Exception) {
                val msg = "(no answer yet: ${e.message ?: e.javaClass.simpleName})"
                if (msg != last) say(msg)
                last = msg
            }
            if (res.isNotEmpty()) {
                val shown = res.trim().take(160)
                if (shown != last) say("playit: " + shown)
                last = shown
            }
            if (res.contains("UserAccepted")) {
                try {
                    val ex = httpPost("https://api.playit.gg/claim/exchange", "{\"code\":\"" + code + "\"}")
                    val m = Regex("\"secret_key\"\\s*:\\s*\"([^\"]+)\"").find(ex)
                    if (m != null) return m.groupValues[1]
                    say("Could not read the key from playit: " + ex.trim().take(200))
                } catch (e: Exception) {
                    say("ERROR while finishing the link: ${e.message ?: e.javaClass.simpleName}")
                }
                return null
            }
            if (res.contains("UserRejected")) {
                say("The link was rejected on playit.gg. Tap Start tunnel to try again.")
                return null
            }
            if (res.contains("CodeExpired")) {
                say("The link expired. Tap Start tunnel to get a new one.")
                return null
            }
            Thread.sleep(2000)
        }
        if (!stopping) say("Waited 10 minutes. Tap Start tunnel to try again.")
        return null
    }

    // ------------------------------------------------------------------
    // Starting the program

    private fun commandsOf(help: String): List<String> {
        val lines = help.lines()
        val at = lines.indexOfFirst { it.trim() == "Commands:" }
        if (at < 0) return emptyList()
        val out = ArrayList<String>()
        for (i in (at + 1) until lines.size) {
            val l = lines[i]
            if (l.isBlank() || !l.startsWith(" ")) break
            val first = l.trim().split(Regex("\\s+")).firstOrNull() ?: continue
            if (first != "help") out.add(first)
        }
        return out
    }

    private fun buildAttempts(bin: File, key: String): List<Attempt> {
        val help = try { runRaw(bin, listOf("--help")) } catch (e: Exception) { "" }
        val secret = secretFile.absolutePath
        val sock = socketFile.absolutePath
        val noHelp = help.isBlank()

        val secretFlag = listOf("--secret-path", "--secret_path", "--secret-file", "--secret_file")
            .firstOrNull { help.contains(it) } ?: (if (noHelp) "--secret-path" else null)
        val hasSocket = noHelp || help.contains("--socket-path")
        val hasStdout = help.contains("--stdout")

        val subs = commandsOf(help)
        val wanted = listOf("daemon", "run", "start", "agent", "up", "serve", "service").filter { it in subs }
        val prefixes = ArrayList<List<String>>()
        prefixes.add(emptyList())
        wanted.forEach { prefixes.add(listOf(it)) }

        val envKey = mapOf(
            "SECRET_KEY" to key,
            "SECRET_KEY_FILE" to keyFile.absolutePath,
            "PLAYIT_SECRET" to key
        )

        val list = ArrayList<Attempt>()
        val seen = HashSet<String>()
        fun add(args: List<String>, env: Map<String, String>) {
            val id = args.joinToString(" ") + "|" + env.keys.sorted().joinToString(",")
            if (seen.add(id)) list.add(Attempt(args, env))
        }

        for (pre in prefixes) {
            val socketArgs = if (hasSocket) listOf("--socket-path", sock) else emptyList()
            val stdoutArgs = if (hasStdout) listOf("--stdout") else emptyList()
            if (secretFlag != null) {
                val s = listOf(secretFlag, secret)
                add(pre + stdoutArgs + s + socketArgs, emptyMap())
                add(pre + s + socketArgs, emptyMap())
                add(pre + s, emptyMap())
            }
            // secret given by environment (works for programs without a secret flag)
            add(pre + stdoutArgs + socketArgs, envKey)
            add(pre + socketArgs, envKey)
            add(pre + stdoutArgs + socketArgs + listOf(key), emptyMap())
        }
        return list.take(14)
    }

    private fun runAttempts(bin: File, key: String) {
        dir.mkdirs()
        val attempts = buildAttempts(bin, key)
        val rejected = HashSet<String>()
        val unexpected = Regex("unexpected argument '([^']+)'")
        var ranLong = false
        for (a in attempts) {
            if (stopping) break
            if (a.args.any { it in rejected }) continue
            say("Starting: " + bin.name + " " + a.args.joinToString(" ").replace(key, "***"))
            val began = System.currentTimeMillis()
            val seenText = StringBuilder()
            val code = try {
                runOnce(bin, a, key, seenText)
            } catch (e: Exception) {
                say("ERROR: ${e.message ?: e.javaClass.simpleName}")
                -1
            }
            if (stopping) break
            if (System.currentTimeMillis() - began > 15_000) {
                ranLong = true
                say("The tunnel stopped (code $code).")
                break
            }
            say("It stopped right away (code $code).")
            for (m in unexpected.findAll(seenText.toString())) rejected.add(m.groupValues[1])
        }
        if (!ranLong && !stopping) {
            say("No way worked. Tap Copy log and send it to me.")
        }
        ui {
            process = null
            state = if (stopping || ranLong) State.Ready else State.Failed
            if (stopping) say("Tunnel stopped.")
        }
    }

    private fun runOnce(bin: File, a: Attempt, key: String, seenText: StringBuilder): Int {
        socketFile.delete()
        val pb = ProcessBuilder(listOf(bin.absolutePath) + a.args)
        pb.environment().putAll(env())
        pb.environment().putAll(a.env)
        pb.directory(dir)
        pb.redirectErrorStream(true)
        val p = pb.start()
        process = p
        ui { state = State.Running }
        pollAddresses(key, p)
        val ansi = Regex("\u001B\\[[0-9;?]*[A-Za-z]")
        val claim = Regex("https://playit\\.gg/claim/\\S+")
        p.inputStream.bufferedReader().use { r ->
            while (true) {
                val raw = r.readLine() ?: break
                val text = ansi.replace(raw, "").replace("\r", "").trim().replace(key, "***")
                if (text.isEmpty()) continue
                if (seenText.length < 4000) seenText.append(text).append('\n')
                say(text)
                val c = claim.find(text)
                if (c != null) ui { claimUrl = c.value }
                addAddresses(text)
            }
        }
        return p.waitFor()
    }

    private val addrRegex = Regex("([a-z0-9-]+\\.)+(joinmc\\.link|ply\\.gg)(:\\d+)?")

    private fun addAddresses(text: String) {
        for (m in addrRegex.findAll(text)) {
            val a = m.value
            ui { if (!addresses.contains(a)) addresses.add(a) }
        }
    }

    /** playit prints no addresses itself, so ask its web API every few seconds while it runs. */
    private fun pollAddresses(key: String, p: Process) {
        thread {
            var first = true
            while (!stopping) {
                try {
                    Thread.sleep(15_000)
                } catch (e: InterruptedException) {
                    return@thread
                }
                if (!p.isAlive) return@thread
                try {
                    val body = httpPost("https://api.playit.gg/v1/agents/rundata", "{}", key)
                    addAddresses(body)
                } catch (e: Exception) {
                    if (first) say("(could not read the address list: ${e.message ?: e.javaClass.simpleName})")
                }
                first = false
            }
        }
    }
}
