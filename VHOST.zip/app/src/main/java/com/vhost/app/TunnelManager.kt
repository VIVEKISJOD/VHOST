package com.vhost.app

import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Runs the playit.gg program (Termux build) so friends in other cities can join.
 * Everything it prints is kept in a log so problems can be read and copied.
 */
class TunnelManager(
    private val context: android.content.Context,
    private val prefs: Prefs,
    private val java: JavaRuntime
) {

    enum class State { NotInstalled, Installing, Ready, Starting, Running, Failed }

    var state by mutableStateOf(State.NotInstalled)
        private set
    var claimUrl by mutableStateOf("")
        private set
    val addresses = mutableStateListOf<String>()
    val log = mutableStateListOf<String>()

    private val dir = File(context.filesDir, "tunnel")
    private val secretFile = File(dir, "playit.toml")
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var process: Process? = null
    @Volatile private var stopping = false
    @Volatile private var startedByServer = false

    init {
        refresh()
    }

    private fun ui(block: () -> Unit) {
        main.post(block)
    }

    private fun say(text: String) {
        ui {
            text.lines().forEach { if (it.isNotBlank()) log.add(it) }
            while (log.size > 400) log.removeAt(0)
        }
    }

    fun binary(): File? {
        return listOf("playit-cli", "playit")
            .map { File(java.prefix, "bin/$it") }
            .firstOrNull { it.exists() }
    }

    fun hasSecret(): Boolean = secretFile.exists() && secretFile.length() > 0

    /** Call when the screen opens, to notice if the files were removed. */
    fun refresh() {
        if (state == State.Installing || state == State.Starting || state == State.Running) return
        state = if (binary() != null) State.Ready else State.NotInstalled
    }

    fun install() {
        if (state == State.Installing || state == State.Starting || state == State.Running) return
        state = State.Installing
        log.clear()
        thread {
            try {
                java.installExtra(listOf("playit", "ca-certificates"), setOf("ca-certificates")) { say(it) }
                val bin = binary() ?: throw IllegalStateException("The playit program was not found after installing.")
                bin.setExecutable(true, false)
                say("Installed: ${bin.name}")
                say("Checking it starts…")
                say(runQuick(bin, listOf("--help")))
                ui { state = State.Ready }
            } catch (e: Exception) {
                say("ERROR: ${e.message ?: e.javaClass.simpleName}")
                ui { state = State.Failed }
            }
        }
    }

    fun start(byServer: Boolean = false) {
        if (state != State.Ready && state != State.Failed) return
        val bin = binary()
        if (bin == null) {
            say("Install the tunnel first.")
            return
        }
        startedByServer = byServer
        stopping = false
        state = State.Starting
        thread { runAttempts(bin) }
    }

    /** Called when the server is online: start the tunnel if it is set up and the setting is on. */
    fun autoStart() {
        if (prefs.tunnelAutoStart && hasSecret() && binary() != null) start(true)
    }

    /** Called when the server stops. */
    fun autoStop() {
        if (startedByServer) stop()
    }

    fun stop() {
        stopping = true
        val p = process ?: return
        thread {
            p.destroy()
            try {
                if (!p.waitFor(5, TimeUnit.SECONDS)) p.destroyForcibly()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    // ------------------------------------------------------------------

    private fun env(): Map<String, String> {
        val e = HashMap(java.environment())
        val cert = File(java.prefix, "etc/tls/cert.pem")
        if (cert.exists()) {
            e["SSL_CERT_FILE"] = cert.absolutePath
            e["SSL_CERT_DIR"] = File(java.prefix, "etc/tls").absolutePath
        }
        return e
    }

    private fun runQuick(bin: File, args: List<String>): String {
        val pb = ProcessBuilder(listOf(bin.absolutePath) + args)
        pb.environment().putAll(env())
        dir.mkdirs()
        pb.directory(dir)
        pb.redirectErrorStream(true)
        val p = pb.start()
        val text = p.inputStream.bufferedReader().readText()
        p.waitFor(15, TimeUnit.SECONDS)
        return text.trim().lines().take(30).joinToString("\n")
    }

    private fun runAttempts(bin: File) {
        dir.mkdirs()
        val attempts = listOf(
            listOf("--stdout", "--secret_path", secretFile.absolutePath),
            listOf("--secret_path", secretFile.absolutePath)
        )
        var ranLong = false
        for (args in attempts) {
            if (stopping) break
            say("Starting: ${bin.name} ${args.joinToString(" ")}")
            val began = System.currentTimeMillis()
            val code = try {
                runOnce(bin, args)
            } catch (e: Exception) {
                say("ERROR: ${e.message ?: e.javaClass.simpleName}")
                -1
            }
            if (stopping) break
            if (System.currentTimeMillis() - began > 15_000) {
                ranLong = true
                say("The tunnel stopped (code $code).")
                break
            }
            say("It stopped right away (code $code).")
        }
        ui {
            process = null
            state = if (stopping || ranLong) State.Ready else State.Failed
            if (stopping) say("Tunnel stopped.")
        }
    }

    private fun runOnce(bin: File, args: List<String>): Int {
        val pb = ProcessBuilder(listOf(bin.absolutePath) + args)
        pb.environment().putAll(env())
        pb.directory(dir)
        pb.redirectErrorStream(true)
        val p = pb.start()
        process = p
        ui { state = State.Running }
        val ansi = Regex("\u001B\\[[0-9;?]*[A-Za-z]")
        val claim = Regex("https://playit\\.gg/claim/\\S+")
        val addr = Regex("([a-z0-9-]+\\.)+(joinmc\\.link|ply\\.gg)(:\\d+)?")
        p.inputStream.bufferedReader().use { r ->
            while (true) {
                val raw = r.readLine() ?: break
                val text = ansi.replace(raw, "").replace("\r", "").trim()
                if (text.isEmpty()) continue
                say(text)
                val c = claim.find(text)
                if (c != null) ui { claimUrl = c.value }
                for (m in addr.findAll(text)) {
                    val a = m.value
                    ui { if (!addresses.contains(a)) addresses.add(a) }
                }
            }
        }
        return p.waitFor()
    }
}
