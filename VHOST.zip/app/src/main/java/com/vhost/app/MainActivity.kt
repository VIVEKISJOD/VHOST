package com.vhost.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

/** One shared copy of settings and updater for the whole app. */
object Shared {
    private var prefs: Prefs? = null
    private var updater: Updater? = null
    private var java: JavaRuntime? = null

    fun prefs(context: Context): Prefs =
        prefs ?: Prefs(context.applicationContext).also { prefs = it }

    fun updater(context: Context): Updater =
        updater ?: Updater(context.applicationContext).also { updater = it }

    fun java(context: Context): JavaRuntime =
        java ?: JavaRuntime(context.applicationContext).also { java = it }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val prefs = Shared.prefs(this)
        val updater = Shared.updater(this)
        val java = Shared.java(this)

        setContent {
            VhostTheme(prefs) {
                val dark = isDarkTheme(prefs.theme, isSystemInDarkTheme())
                val view = LocalView.current
                SideEffect {
                    val controller = WindowCompat.getInsetsController(window, view)
                    controller.isAppearanceLightStatusBars = !dark
                    controller.isAppearanceLightNavigationBars = !dark
                }

                LaunchedEffect(Unit) {
                    if (prefs.checkUpdatesOnStart) {
                        updater.check(prefs.updateRepo, quiet = true)
                    }
                }

                var screen by rememberSaveable { mutableStateOf("home") }
                BackHandler(enabled = screen != "home") { screen = "home" }

                when (screen) {
                    "settings" -> SettingsScreen(prefs, updater, onBack = { screen = "home" })
                    "java" -> JavaScreen(java, onBack = { screen = "home" })
                    else -> HomeScreen(
                        prefs,
                        updater,
                        java,
                        onOpenSettings = { screen = "settings" },
                        onOpenJava = { screen = "java" }
                    )
                }
            }
        }
    }
}
