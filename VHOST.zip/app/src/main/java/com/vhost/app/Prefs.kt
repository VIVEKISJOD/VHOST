package com.vhost.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** All app settings. Values are saved on the device and also kept as Compose state. */
class Prefs(context: Context) {
    private val sp: SharedPreferences =
        context.getSharedPreferences("vhost_settings", Context.MODE_PRIVATE)

    // ---- Appearance ----
    var theme by mutableStateOf(sp.getString("theme", "dark") ?: "dark")
        private set
    var accent by mutableStateOf(sp.getString("accent", "torch") ?: "torch")
        private set

    // ---- Updates ----
    var checkUpdatesOnStart by mutableStateOf(sp.getBoolean("check_updates", true))
        private set
    var updateRepo by mutableStateOf(sp.getString("update_repo", DEFAULT_REPO) ?: DEFAULT_REPO)
        private set

    // ---- Server defaults (used by the server runner in the next step) ----
    var ramMb by mutableStateOf(sp.getInt("ram_mb", 1536))
        private set
    var port by mutableStateOf(sp.getInt("port", 25565))
        private set
    var maxPlayers by mutableStateOf(sp.getInt("max_players", 10))
        private set
    var autoStartOnOpen by mutableStateOf(sp.getBoolean("auto_start", false))
        private set
    var autoRestartOnCrash by mutableStateOf(sp.getBoolean("auto_restart", true))
        private set
    var keepAwake by mutableStateOf(sp.getBoolean("keep_awake", true))
        private set
    var onlyWhileCharging by mutableStateOf(sp.getBoolean("only_charging", false))
        private set
    var stopOnLowBattery by mutableStateOf(sp.getBoolean("stop_low_battery", true))
        private set
    var lowBatteryPercent by mutableStateOf(sp.getInt("low_battery_pct", 15))
        private set
    var onlyOnWifi by mutableStateOf(sp.getBoolean("only_wifi", false))
        private set
    var autoBackup by mutableStateOf(sp.getBoolean("auto_backup", true))
        private set
    var backupEveryMinutes by mutableStateOf(sp.getInt("backup_minutes", 60))
        private set
    var autoStopWhenEmpty by mutableStateOf(sp.getBoolean("auto_stop_empty", false))
        private set
    var emptyStopMinutes by mutableStateOf(sp.getInt("empty_stop_minutes", 30))
        private set

    // ---- Alerts ----
    var notifyStarted by mutableStateOf(sp.getBoolean("n_started", true))
        private set
    var notifyPlayerJoin by mutableStateOf(sp.getBoolean("n_join", true))
        private set
    var notifyCrash by mutableStateOf(sp.getBoolean("n_crash", true))
        private set

    fun setTheme(v: String) { theme = v; sp.edit().putString("theme", v).apply() }
    fun setAccent(v: String) { accent = v; sp.edit().putString("accent", v).apply() }
    fun setCheckUpdatesOnStart(v: Boolean) { checkUpdatesOnStart = v; sp.edit().putBoolean("check_updates", v).apply() }
    fun setUpdateRepo(v: String) { updateRepo = v.trim(); sp.edit().putString("update_repo", v.trim()).apply() }
    fun setRamMb(v: Int) { ramMb = v; sp.edit().putInt("ram_mb", v).apply() }
    fun setPort(v: Int) { port = v; sp.edit().putInt("port", v).apply() }
    fun setMaxPlayers(v: Int) { maxPlayers = v; sp.edit().putInt("max_players", v).apply() }
    fun setAutoStartOnOpen(v: Boolean) { autoStartOnOpen = v; sp.edit().putBoolean("auto_start", v).apply() }
    fun setAutoRestartOnCrash(v: Boolean) { autoRestartOnCrash = v; sp.edit().putBoolean("auto_restart", v).apply() }
    fun setKeepAwake(v: Boolean) { keepAwake = v; sp.edit().putBoolean("keep_awake", v).apply() }
    fun setOnlyWhileCharging(v: Boolean) { onlyWhileCharging = v; sp.edit().putBoolean("only_charging", v).apply() }
    fun setStopOnLowBattery(v: Boolean) { stopOnLowBattery = v; sp.edit().putBoolean("stop_low_battery", v).apply() }
    fun setLowBatteryPercent(v: Int) { lowBatteryPercent = v; sp.edit().putInt("low_battery_pct", v).apply() }
    fun setOnlyOnWifi(v: Boolean) { onlyOnWifi = v; sp.edit().putBoolean("only_wifi", v).apply() }
    fun setAutoBackup(v: Boolean) { autoBackup = v; sp.edit().putBoolean("auto_backup", v).apply() }
    fun setBackupEveryMinutes(v: Int) { backupEveryMinutes = v; sp.edit().putInt("backup_minutes", v).apply() }
    fun setAutoStopWhenEmpty(v: Boolean) { autoStopWhenEmpty = v; sp.edit().putBoolean("auto_stop_empty", v).apply() }
    fun setEmptyStopMinutes(v: Int) { emptyStopMinutes = v; sp.edit().putInt("empty_stop_minutes", v).apply() }
    fun setNotifyStarted(v: Boolean) { notifyStarted = v; sp.edit().putBoolean("n_started", v).apply() }
    fun setNotifyPlayerJoin(v: Boolean) { notifyPlayerJoin = v; sp.edit().putBoolean("n_join", v).apply() }
    fun setNotifyCrash(v: Boolean) { notifyCrash = v; sp.edit().putBoolean("n_crash", v).apply() }

    fun resetAll() {
        setTheme("dark"); setAccent("torch")
        setCheckUpdatesOnStart(true); setUpdateRepo(DEFAULT_REPO)
        setRamMb(1536); setPort(25565); setMaxPlayers(10)
        setAutoStartOnOpen(false); setAutoRestartOnCrash(true); setKeepAwake(true)
        setOnlyWhileCharging(false); setStopOnLowBattery(true); setLowBatteryPercent(15)
        setOnlyOnWifi(false); setAutoBackup(true); setBackupEveryMinutes(60)
        setAutoStopWhenEmpty(false); setEmptyStopMinutes(30)
        setNotifyStarted(true); setNotifyPlayerJoin(true); setNotifyCrash(true)
    }

    companion object {
        const val DEFAULT_REPO = "VIVEKISJOD/VHOST"
    }
}
