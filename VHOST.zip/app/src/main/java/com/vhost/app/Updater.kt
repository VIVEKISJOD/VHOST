package com.vhost.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/** Checks GitHub Releases for a newer build, downloads it and opens the installer. */
class Updater(private val context: Context) {

    enum class State { Idle, Checking, UpToDate, Available, Downloading, ReadyToInstall, Error }

    var state by mutableStateOf(State.Idle)
        private set
    var message by mutableStateOf("")
        private set
    var newBuild by mutableStateOf(0)
        private set
    var notes by mutableStateOf("")
        private set
    var progress by mutableStateOf(0f)
        private set

    var apkUrl by mutableStateOf("")
        private set
    private val main = Handler(Looper.getMainLooper())

    private fun ui(block: () -> Unit) { main.post(block) }

    fun check(repo: String, quiet: Boolean = false) {
        if (state == State.Checking || state == State.Downloading) return
        val cleanRepo = repo.trim().removePrefix("https://github.com/").trim('/')
        if (!cleanRepo.contains("/")) {
            state = State.Error
            message = "Update source must look like owner/repo."
            return
        }
        state = State.Checking
        message = ""
        thread {
            try {
                val conn = URL("https://api.github.com/repos/$cleanRepo/releases/latest")
                    .openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 15000
                conn.setRequestProperty("Accept", "application/vnd.github+json")
                conn.setRequestProperty("User-Agent", "VHOST-App")
                val code = conn.responseCode
                if (code == 404) {
                    ui {
                        state = if (quiet) State.Idle else State.Error
                        message = "No release found. Make sure the repo is public and a build has finished."
                    }
                    return@thread
                }
                if (code != 200) {
                    ui {
                        state = if (quiet) State.Idle else State.Error
                        message = "GitHub answered with code $code."
                    }
                    return@thread
                }
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val tag = json.optString("tag_name", "")
                val number = tag.filter { it.isDigit() }.toIntOrNull() ?: 0
                val assets = json.optJSONArray("assets")
                var url = ""
                if (assets != null) {
                    for (i in 0 until assets.length()) {
                        val a = assets.getJSONObject(i)
                        if (a.optString("name").endsWith(".apk")) {
                            url = a.optString("browser_download_url")
                            break
                        }
                    }
                }
                val releaseNotes = json.optString("body", "")
                ui {
                    if (number > BuildConfig.VERSION_CODE && url.isNotEmpty()) {
                        apkUrl = url
                        newBuild = number
                        notes = releaseNotes
                        state = State.Available
                    } else {
                        state = if (quiet) State.Idle else State.UpToDate
                        message = "You have the latest build."
                    }
                }
            } catch (e: Exception) {
                ui {
                    state = if (quiet) State.Idle else State.Error
                    message = "Could not check for updates. Check your internet."
                }
            }
        }
    }

    /** Opens the download link in the phone's browser (backup way to get the update). */
    fun openInBrowser() {
        if (apkUrl.isEmpty()) return
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(apkUrl))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)
        } catch (e: Exception) {
            message = "Could not open the browser."
        }
    }

    /** Opens one connection and follows redirects by hand (GitHub sends the file from another host). */
    private fun openConnection(startUrl: String, rangeFrom: Long): HttpURLConnection {
        var current = startUrl
        var hops = 0
        while (true) {
            val c = URL(current).openConnection() as HttpURLConnection
            c.connectTimeout = 20000
            c.readTimeout = 60000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "VHOST-App")
            c.setRequestProperty("Accept", "application/octet-stream")
            c.setRequestProperty("Accept-Encoding", "identity")
            if (rangeFrom > 0) c.setRequestProperty("Range", "bytes=$rangeFrom-")
            val code = c.responseCode
            if (code in 301..308 && code != 304) {
                val loc = c.getHeaderField("Location") ?: throw IOException("redirect without address")
                c.disconnect()
                current = URL(URL(current), loc).toString()
                hops++
                if (hops > 8) throw IOException("too many redirects")
                continue
            }
            return c
        }
    }

    fun download() {
        if (apkUrl.isEmpty() || state == State.Downloading) return
        state = State.Downloading
        progress = 0f
        message = ""
        val url = apkUrl
        val build = newBuild
        thread {
            var lastError = ""
            var ok = false
            try {
                val dir = File(context.cacheDir, "updates")
                dir.mkdirs()
                val file = File(dir, "VHOST.apk")
                val part = File(dir, "VHOST-$build.part")
                // remove the old finished file and parts from other builds
                dir.listFiles()?.forEach { if (it.name != part.name) it.delete() }

                for (attempt in 1..4) {
                    try {
                        val have = if (part.exists()) part.length() else 0L
                        val c = openConnection(url, have)
                        val code = c.responseCode
                        if (code == 416) {
                            part.delete()
                            throw IOException("restarting")
                        }
                        if (code != 200 && code != 206) throw IOException("server answered $code")
                        val append = code == 206 && have > 0
                        val start = if (append) have else 0L
                        val len = c.contentLengthLong
                        val total = if (len > 0) start + len else -1L
                        var done = start
                        c.inputStream.use { input ->
                            FileOutputStream(part, append).use { out ->
                                val buf = ByteArray(32 * 1024)
                                var lastShown = 0L
                                while (true) {
                                    val n = input.read(buf)
                                    if (n < 0) break
                                    out.write(buf, 0, n)
                                    done += n
                                    val now = System.currentTimeMillis()
                                    if (total > 0 && now - lastShown > 200) {
                                        lastShown = now
                                        val p = done.toFloat() / total.toFloat()
                                        ui { progress = p }
                                    }
                                }
                            }
                        }
                        c.disconnect()
                        if (total > 0 && part.length() < total) throw IOException("connection was cut")
                        if (part.length() < 100_000L) throw IOException("file too small")
                        ok = true
                        break
                    } catch (e: Exception) {
                        lastError = (e.message ?: e.javaClass.simpleName)
                        try { Thread.sleep(2000) } catch (ie: InterruptedException) {}
                    }
                }
                if (ok) {
                    file.delete()
                    if (!part.renameTo(file)) {
                        ok = false
                        lastError = "could not save the file"
                    }
                }
            } catch (e: Exception) {
                ok = false
                lastError = (e.message ?: e.javaClass.simpleName)
            }
            ui {
                if (ok) {
                    state = State.ReadyToInstall
                    install()
                } else {
                    state = State.Error
                    message = "Download failed ($lastError). Tap Try again, or Open in browser."
                }
            }
        }
    }

    /** Opens the Android installer. If the permission is missing, opens that setting first. */
    fun install() {
        try {
            val file = File(File(context.cacheDir, "updates"), "VHOST.apk")
            if (!file.exists()) {
                state = State.Error
                message = "Update file is missing. Tap Try again."
                return
            }
            if (!context.packageManager.canRequestPackageInstalls()) {
                message = "Allow VHOST to install apps, then tap Install again."
                val i = Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + context.packageName)
                )
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                return
            }
            val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, "application/vnd.android.package-archive")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)
        } catch (e: Exception) {
            state = State.Error
            message = "Could not open the installer (${e.message ?: e.javaClass.simpleName}). Try Open in browser."
        }
    }

    fun dismiss() {
        if (state == State.Available || state == State.UpToDate || state == State.Error) {
            state = State.Idle
        }
    }
}
