package com.vhost.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/** Checks GitHub Releases for a newer build, downloads it and opens the installer. */
class Updater(private val context: Context) {

    enum class State { Idle, Checking, UpToDate, Available, Downloading, ReadyToInstall, Error }

    var state by mutableStateOf(State.Idle)
        private set
    var message by mutableStateOf("")
        private set
    var newBuild by mutableStateOf(0)
        private set
    var notes by mutableStateOf("")
        private set
    var progress by mutableStateOf(0f)
        private set

    private var apkUrl: String = ""
    private val main = Handler(Looper.getMainLooper())

    private fun ui(block: () -> Unit) { main.post(block) }

    fun check(repo: String, quiet: Boolean = false) {
        if (state == State.Checking || state == State.Downloading) return
        val cleanRepo = repo.trim().removePrefix("https://github.com/").trim('/')
        if (!cleanRepo.contains("/")) {
            state = State.Error
            message = "Update source must look like owner/repo."
            return
        }
        state = State.Checking
        message = ""
        thread {
            try {
                val conn = URL("https://api.github.com/repos/$cleanRepo/releases/latest")
                    .openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 15000
                conn.setRequestProperty("Accept", "application/vnd.github+json")
                conn.setRequestProperty("User-Agent", "VHOST-App")
                val code = conn.responseCode
                if (code == 404) {
                    ui {
                        state = if (quiet) State.Idle else State.Error
                        message = "No release found. Make sure the repo is public and a build has finished."
                    }
                    return@thread
                }
                if (code != 200) {
                    ui {
                        state = if (quiet) State.Idle else State.Error
                        message = "GitHub answered with code $code."
                    }
                    return@thread
                }
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val tag = json.optString("tag_name", "")
                val number = tag.filter { it.isDigit() }.toIntOrNull() ?: 0
                val assets = json.optJSONArray("assets")
                var url = ""
                if (assets != null) {
                    for (i in 0 until assets.length()) {
                        val a = assets.getJSONObject(i)
                        if (a.optString("name").endsWith(".apk")) {
                            url = a.optString("browser_download_url")
                            break
                        }
                    }
                }
                val releaseNotes = json.optString("body", "")
                ui {
                    if (number > BuildConfig.VERSION_CODE && url.isNotEmpty()) {
                        apkUrl = url
                        newBuild = number
                        notes = releaseNotes
                        state = State.Available
                    } else {
                        state = if (quiet) State.Idle else State.UpToDate
                        message = "You have the latest build."
                    }
                }
            } catch (e: Exception) {
                ui {
                    state = if (quiet) State.Idle else State.Error
                    message = "Could not check for updates. Check your internet."
                }
            }
        }
    }

    fun download() {
        if (apkUrl.isEmpty() || state == State.Downloading) return
        state = State.Downloading
        progress = 0f
        thread {
            try {
                val dir = File(context.cacheDir, "updates")
                dir.mkdirs()
                dir.listFiles()?.forEach { it.delete() }
                val file = File(dir, "VHOST.apk")
                val conn = URL(apkUrl).openConnection() as HttpURLConnection
                conn.connectTimeout = 20000
                conn.readTimeout = 30000
                conn.setRequestProperty("User-Agent", "VHOST-App")
                conn.instanceFollowRedirects = true
                val total = conn.contentLengthLong
                var done = 0L
                conn.inputStream.use { input ->
                    file.outputStream().use { out ->
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val p = done.toFloat() / total.toFloat()
                                ui { progress = p }
                            }
                        }
                    }
                }
                ui {
                    state = State.ReadyToInstall
                    install()
                }
            } catch (e: Exception) {
                ui {
                    state = State.Error
                    message = "Download failed. Try again."
                }
            }
        }
    }

    /** Opens the Android installer. If the permission is missing, opens that setting first. */
    fun install() {
        val file = File(File(context.cacheDir, "updates"), "VHOST.apk")
        if (!file.exists()) {
            state = State.Error
            message = "Update file is missing. Download again."
            return
        }
        if (!context.packageManager.canRequestPackageInstalls()) {
            message = "Allow VHOST to install apps, then tap Install again."
            val i = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:" + context.packageName)
            )
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)
            return
        }
        val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(i)
    }

    fun dismiss() {
        if (state == State.Available || state == State.UpToDate || state == State.Error) {
            state = State.Idle
        }
    }
}
