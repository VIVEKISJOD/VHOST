Build 4: update download fix
- Fixed "Download failed" when updating inside the app (redirects, resume, retries)
- Failed downloads now show the real reason, plus Try again and Open in browser buttons
- Java setup from build 3 is still included
