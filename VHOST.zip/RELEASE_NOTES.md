Build 8: tunnel fix (new playit version)
- Tunnel: the new playit program has different options. The app now reads them itself and picks the right ones
- Account link now happens inside the app: tap Start tunnel, then Open link and approve on playit.gg
- Backup way: paste a secret key from playit.gg if the link does not work
- Public addresses are read from playit automatically (you can still paste them by hand)
- Unlink account button added
