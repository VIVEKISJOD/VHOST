Build 7: Bedrock + friends tunnel + update fix
- Update now downloads with Android's own download manager (more reliable)
- Bedrock players can join: Geyser + Floodgate install by themselves (switch on the Server screen)
- New Friends tunnel screen (playit.gg): friends in other cities can join without your Wi-Fi
- Server screen shows how to join on Wi-Fi and over the tunnel
- Plugin/mod downloads and Aternos-style settings: not built yet
