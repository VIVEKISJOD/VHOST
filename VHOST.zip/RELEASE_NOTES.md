Build 5: server runner
- New Server screen: Start/Stop, live console, send commands
- Downloads Paper (default Minecraft 1.21.11) and runs it on the Java you installed
- Runs in the background with a notification and Stop button
- Settings now work: memory, port, max players, keep awake, restart on crash, battery/Wi-Fi/charging rules, empty-server stop, alerts
- Friends in other cities, Bedrock, backups: not built yet
