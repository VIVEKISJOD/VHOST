First build of VHOST.
- New app shell with Home and Settings screens
- In-app updates from GitHub: a banner appears when a new build is ready
- Settings for updates, appearance, server defaults, background running, backups and notifications
- The server runner comes in the next build
