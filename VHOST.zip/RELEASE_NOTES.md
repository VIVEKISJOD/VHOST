Java setup
- New Java card on Home: installs a Java runtime inside the app and tests it
- Shows a live log you can copy
- Server runner comes after Java is confirmed working on your device
